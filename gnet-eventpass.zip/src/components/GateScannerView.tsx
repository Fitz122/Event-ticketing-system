import React, { useEffect, useRef, useState } from 'react';
import { audioService } from '../services/audioService';
import { CryptoService } from '../services/cryptoService';
import { storageService } from '../services/storageService';
import { CheckInLogEntry, EventItem, Ticket } from '../types';
import {
  Camera,
  CheckCircle2,
  XCircle,
  AlertTriangle,
  Zap,
  Volume2,
  VolumeX,
  RefreshCw,
  Search,
  Users,
  ShieldCheck,
  Wifi,
  WifiOff,
} from 'lucide-react';

interface GateScannerViewProps {
  events: EventItem[];
  tickets: Ticket[];
  onCheckInCompleted: () => void;
  isOfflineMode: boolean;
}

export const GateScannerView: React.FC<GateScannerViewProps> = ({
  events,
  tickets,
  onCheckInCompleted,
  isOfflineMode,
}) => {
  const [selectedEventId, setSelectedEventId] = useState<string>(events[0]?.id || '');
  const [selectedGate, setSelectedGate] = useState<string>('Gate A - VIP & Hospitality');
  const [manualCode, setManualCode] = useState<string>('');
  const [staffName, setStaffName] = useState<string>('Officer J. Mutua (Staff #14)');
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);

  const [scanResult, setScanResult] = useState<{
    status: 'idle' | 'valid' | 'duplicate' | 'invalid';
    message: string;
    ticket?: Ticket;
    timestamp?: string;
  }>({ status: 'idle', message: '' });

  const [logs, setLogs] = useState<CheckInLogEntry[]>([]);
  const [cameraActive, setCameraActive] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const currentEvent = events.find((e) => e.id === selectedEventId) || events[0];

  useEffect(() => {
    setLogs(storageService.getCheckInLogs());
  }, []);

  // Handle Camera Setup
  const startCamera = async () => {
    setCameraError(null);
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Camera access not supported on this browser/environment.');
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } },
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      setCameraActive(true);
    } catch (err: unknown) {
      console.warn('Camera failed:', err);
      setCameraError('Camera access unavailable or blocked. You can use the Quick Test Scanner or manual input.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach((track) => track.stop());
      streamRef.current = null;
    }
    setCameraActive(false);
  };

  useEffect(() => {
    return () => {
      stopCamera();
    };
  }, []);

  // Process a Scanned Code (either from camera, QR payload, or manual)
  const processScan = async (rawCode: string) => {
    if (!rawCode.trim()) return;

    const verification = await CryptoService.verifyQrPayload(rawCode);
    const targetTicketNumber = verification.ticketNumber || rawCode.trim();

    const result = storageService.markTicketCheckedIn(targetTicketNumber, selectedGate, staffName);

    if (result.success && result.ticket) {
      // Valid Check-In
      const isVip = result.ticket.tierName.toLowerCase().includes('vip');
      if (soundEnabled) {
        if (isVip) {
          audioService.playVipFanfare();
        } else {
          audioService.playValidCheckIn();
        }
      }

      setScanResult({
        status: 'valid',
        message: `VALID TICKET — Welcome ${result.ticket.attendeeName}!`,
        ticket: result.ticket,
        timestamp: new Date().toLocaleTimeString(),
      });
    } else if (result.ticket && result.ticket.isCheckedIn) {
      // Duplicate Pass-Back
      if (soundEnabled) audioService.playDuplicateAlert();

      setScanResult({
        status: 'duplicate',
        message: result.reason || 'ALREADY CHECKED IN — Duplicate scan detected!',
        ticket: result.ticket,
        timestamp: new Date().toLocaleTimeString(),
      });
    } else {
      // Invalid code
      if (soundEnabled) audioService.playDuplicateAlert();

      setScanResult({
        status: 'invalid',
        message: result.reason || 'INVALID TICKET CODE — Not recognized in manifest database.',
        timestamp: new Date().toLocaleTimeString(),
      });
    }

    setLogs(storageService.getCheckInLogs());
    onCheckInCompleted();
    setManualCode('');
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    processScan(manualCode);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Turnstile Station Control Bar */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="text-emerald-400 font-bold uppercase tracking-wider">Turnstile Station</span>
            <span>·</span>
            <span>GNet High-Speed Check-in Engine</span>
            <span>·</span>
            <span className="font-mono text-white">{staffName}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            Gate Turnstile Scanner & Capacity Controller
          </h1>
          <p className="text-xs text-neutral-400 mt-1">
            Sub-millisecond verification with cryptographic HMAC signature check, duplicate pass-back prevention, and VIP alerts.
          </p>
        </div>

        {/* Station Settings */}
        <div className="flex flex-wrap items-center gap-3">
          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled((prev) => !prev)}
            className={`p-2.5 rounded-xl border text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer ${
              soundEnabled
                ? 'bg-neutral-800 text-white border-neutral-700'
                : 'bg-neutral-950 text-neutral-500 border-neutral-800'
            }`}
            title="Audio feedback sound"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">{soundEnabled ? 'Chimes On' : 'Muted'}</span>
          </button>

          {/* Gate Selector */}
          <select
            value={selectedGate}
            onChange={(e) => setSelectedGate(e.target.value)}
            className="bg-neutral-950 text-white text-xs font-semibold px-3 py-2.5 rounded-xl border border-neutral-800 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            <option value="Gate A - VIP & Hospitality">Gate A - VIP & Hospitality</option>
            <option value="Gate B - General East Turnstiles">Gate B - General East Turnstiles</option>
            <option value="Gate C - General West Turnstiles">Gate C - General West Turnstiles</option>
            <option value="Gate D - Media & Production">Gate D - Media & Production</option>
          </select>

          {/* Offline Status */}
          <div className="flex items-center gap-1.5 text-xs px-3 py-2 rounded-xl bg-neutral-950 border border-neutral-800 text-neutral-300">
            {isOfflineMode ? (
              <>
                <WifiOff className="w-3.5 h-3.5 text-amber-400" />
                <span className="text-amber-300 font-semibold">Offline Manifest Cache</span>
              </>
            ) : (
              <>
                <Wifi className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400 font-semibold">Real-Time Sync</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Main Scanner Section Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Col: Camera & Quick Scanner (7 Cols) */}
        <div className="lg:col-span-7 space-y-6">
          {/* Camera Viewport / Live Scanner Box */}
          <div className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-neutral-950 aspect-[4/3] flex flex-col items-center justify-center p-6 shadow-2xl">
            {cameraActive ? (
              <>
                <video
                  ref={videoRef}
                  playsInline
                  muted
                  className="w-full h-full object-cover rounded-2xl"
                />
                {/* Visual Laser Scanner Overlay */}
                <div className="absolute inset-8 pointer-events-none flex flex-col justify-between border-2 border-emerald-500/50 rounded-2xl p-4">
                  <div className="flex justify-between">
                    <div className="w-6 h-6 border-t-2 border-l-2 border-emerald-400"></div>
                    <div className="w-6 h-6 border-t-2 border-r-2 border-emerald-400"></div>
                  </div>
                  {/* Animated laser scan bar */}
                  <div className="w-full h-0.5 bg-emerald-400 shadow-[0_0_12px_rgba(52,211,153,0.9)] animate-bounce"></div>
                  <div className="flex justify-between">
                    <div className="w-6 h-6 border-b-2 border-l-2 border-emerald-400"></div>
                    <div className="w-6 h-6 border-b-2 border-r-2 border-emerald-400"></div>
                  </div>
                </div>

                <div className="absolute bottom-6 flex gap-3">
                  <button
                    onClick={stopCamera}
                    className="px-4 py-2 bg-neutral-900/90 backdrop-blur-md text-white text-xs font-semibold rounded-xl border border-neutral-700 hover:bg-neutral-800 cursor-pointer"
                  >
                    Pause Camera
                  </button>
                </div>
              </>
            ) : (
              <div className="text-center space-y-4 max-w-sm">
                <div className="w-16 h-16 rounded-3xl bg-neutral-900 border border-neutral-800 text-emerald-400 flex items-center justify-center mx-auto shadow-inner">
                  <Camera className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-base font-bold text-white">Live Camera QR Scanner</h3>
                  <p className="text-xs text-neutral-400 mt-1">
                    Scan digital tickets directly from attendee smartphone screens or printed PDF passes.
                  </p>
                </div>

                {cameraError && (
                  <p className="text-xs text-amber-400 bg-amber-950/40 p-2.5 rounded-xl border border-amber-900/60 text-left">
                    {cameraError}
                  </p>
                )}

                <div className="flex flex-col sm:flex-row gap-2 justify-center">
                  <button
                    onClick={startCamera}
                    className="py-2.5 px-5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm"
                  >
                    <Camera className="w-4 h-4" />
                    <span>Launch Camera</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Quick Simulation Bar: Test scanning existing tickets */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-neutral-300 flex items-center gap-1.5 uppercase tracking-wider">
                <Zap className="w-3.5 h-3.5 text-amber-400" />
                Instant Simulation: Scan Sample Attendees
              </span>
              <span className="text-[11px] text-neutral-500 font-mono">1-Click Test</span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {tickets.slice(0, 4).map((t) => (
                <button
                  key={t.id}
                  onClick={() => processScan(t.qrPayload || t.ticketNumber)}
                  className={`p-3 rounded-xl border text-left transition-all cursor-pointer flex items-center justify-between ${
                    t.isCheckedIn
                      ? 'border-neutral-800 bg-neutral-950/40 opacity-70 hover:opacity-100'
                      : 'border-neutral-700 bg-neutral-950 hover:border-emerald-500/80 hover:bg-neutral-900'
                  }`}
                >
                  <div className="truncate mr-2">
                    <p className="text-xs font-bold text-white truncate">{t.attendeeName}</p>
                    <p className="text-[11px] text-neutral-400 font-mono">
                      {t.ticketNumber} · {t.tierName}
                    </p>
                  </div>
                  <span
                    className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded shrink-0 ${
                      t.isCheckedIn
                        ? 'bg-neutral-800 text-neutral-400'
                        : 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                    }`}
                  >
                    {t.isCheckedIn ? 'Checked In' : 'Ready'}
                  </span>
                </button>
              ))}
            </div>

            {/* Test Invalid / Fake QR */}
            <div className="pt-2 flex gap-2">
              <button
                onClick={() => processScan('GNET:INVALID_FORGED_HASH_TOKEN_123')}
                className="py-1.5 px-3 bg-neutral-950 border border-neutral-800 hover:border-rose-800 text-neutral-400 hover:text-rose-400 text-xs rounded-lg transition-colors cursor-pointer"
              >
                Test Forged/Corrupt QR Code
              </button>
              <button
                onClick={() => {
                  const firstCheckedIn = tickets.find((t) => t.isCheckedIn);
                  if (firstCheckedIn) {
                    processScan(firstCheckedIn.qrPayload || firstCheckedIn.ticketNumber);
                  } else if (tickets[0]) {
                    // check in first, then test duplicate
                    processScan(tickets[0].ticketNumber);
                    setTimeout(() => processScan(tickets[0].ticketNumber), 300);
                  }
                }}
                className="py-1.5 px-3 bg-neutral-950 border border-neutral-800 hover:border-amber-800 text-neutral-400 hover:text-amber-400 text-xs rounded-lg transition-colors cursor-pointer"
              >
                Test Duplicate Pass-Back
              </button>
            </div>
          </div>

          {/* Manual Ticket Input */}
          <form onSubmit={handleManualSubmit} className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
              <input
                type="text"
                value={manualCode}
                onChange={(e) => setManualCode(e.target.value)}
                placeholder="Enter Ticket No. (e.g. GNET-2026-8941) or Scan Barcode..."
                className="w-full pl-10 pr-4 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-xs font-mono text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500"
              />
            </div>
            <button
              type="submit"
              className="py-2.5 px-5 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold text-xs rounded-xl transition-colors cursor-pointer"
            >
              Verify Code
            </button>
          </form>
        </div>

        {/* Right Col: Live Feedback Banner & Recent Turnstile Log (5 Cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Real-time Status Card */}
          <div
            className={`p-6 rounded-3xl border transition-all duration-300 ${
              scanResult.status === 'valid'
                ? 'bg-emerald-950/40 border-emerald-500 shadow-xl shadow-emerald-500/10'
                : scanResult.status === 'duplicate'
                ? 'bg-amber-950/40 border-amber-500 shadow-xl shadow-amber-500/10'
                : scanResult.status === 'invalid'
                ? 'bg-rose-950/40 border-rose-500 shadow-xl shadow-rose-500/10'
                : 'bg-neutral-900 border-neutral-800'
            }`}
          >
            <div className="flex items-center gap-3">
              {scanResult.status === 'valid' && (
                <div className="w-12 h-12 rounded-2xl bg-emerald-500 text-neutral-950 flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-7 h-7" />
                </div>
              )}
              {scanResult.status === 'duplicate' && (
                <div className="w-12 h-12 rounded-2xl bg-amber-500 text-neutral-950 flex items-center justify-center shrink-0">
                  <AlertTriangle className="w-7 h-7" />
                </div>
              )}
              {scanResult.status === 'invalid' && (
                <div className="w-12 h-12 rounded-2xl bg-rose-500 text-white flex items-center justify-center shrink-0">
                  <XCircle className="w-7 h-7" />
                </div>
              )}
              {scanResult.status === 'idle' && (
                <div className="w-12 h-12 rounded-2xl bg-neutral-800 text-neutral-400 flex items-center justify-center shrink-0">
                  <RefreshCw className="w-6 h-6 animate-pulse" />
                </div>
              )}

              <div>
                <span className="text-[10px] uppercase font-bold tracking-wider text-neutral-400">
                  Turnstile Status
                </span>
                <h3 className="text-base font-bold text-white mt-0.5">
                  {scanResult.status === 'idle'
                    ? 'Awaiting Next QR Scan'
                    : scanResult.status === 'valid'
                    ? 'ACCESS GRANTED'
                    : scanResult.status === 'duplicate'
                    ? 'ENTRY REJECTED (DUPLICATE)'
                    : 'INVALID TICKET'}
                </h3>
              </div>
            </div>

            <p className="text-xs text-neutral-300 mt-3 leading-relaxed">
              {scanResult.status === 'idle'
                ? `Ready at ${selectedGate}. Position ticket QR in scanner or trigger rapid test.`
                : scanResult.message}
            </p>

            {scanResult.ticket && (
              <div className="mt-4 pt-4 border-t border-white/10 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-neutral-400">Pass Number:</span>
                  <span className="font-mono font-bold text-white">{scanResult.ticket.ticketNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Tier:</span>
                  <span className="font-semibold text-emerald-400">{scanResult.ticket.tierName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-400">Gate:</span>
                  <span className="text-neutral-200">{selectedGate}</span>
                </div>
              </div>
            )}
          </div>

          {/* Recent Check-In Ledger */}
          <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                <Users className="w-4 h-4 text-emerald-400" />
                Turnstile Activity Feed
              </h3>
              <span className="text-xs text-neutral-400 font-mono">
                {logs.length} logged
              </span>
            </div>

            <div className="space-y-2.5 max-h-80 overflow-y-auto pr-1">
              {logs.map((log) => (
                <div
                  key={log.id}
                  className="p-3 bg-neutral-950 border border-neutral-800/80 rounded-xl flex items-center justify-between text-xs"
                >
                  <div className="truncate mr-2">
                    <p className="font-semibold text-white truncate">{log.attendeeName}</p>
                    <p className="text-[11px] text-neutral-400 font-mono">
                      {log.ticketNumber} · {log.gate}
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        log.status === 'valid'
                          ? 'bg-emerald-950 text-emerald-400 border border-emerald-800'
                          : 'bg-rose-950 text-rose-400 border border-rose-800'
                      }`}
                    >
                      {log.status === 'valid' ? 'Verified' : 'Rejected'}
                    </span>
                    <p className="text-[10px] text-neutral-500 font-mono mt-0.5">{log.timestamp}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
