import React, { useState } from 'react';
import { MerchandiseOrder, Ticket } from '../types';
import { QrCode, ShieldCheck, Wifi, WifiOff, Clock, MapPin, CheckCircle, Package } from 'lucide-react';

interface UserDashboardProps {
  tickets: Ticket[];
  merchandiseOrders: MerchandiseOrder[];
  onOpenTicketPass: (ticket: Ticket) => void;
  isOfflineMode: boolean;
  onToggleOffline: () => void;
}

export const UserDashboard: React.FC<UserDashboardProps> = ({
  tickets,
  merchandiseOrders,
  onOpenTicketPass,
  isOfflineMode,
  onToggleOffline,
}) => {
  const [activeTab, setActiveTab] = useState<'passes' | 'orders' | 'settings'>('passes');

  const activePasses = tickets.filter((t) => !t.isCheckedIn);
  const usedPasses = tickets.filter((t) => t.isCheckedIn);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* User Header & Offline Wallet Status Card */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="text-emerald-400 font-semibold">GNet Digital Attendee Passbook</span>
            <span>·</span>
            <span>Fitzgerald Omondi (+254 712 345 678)</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            My Digital Passes & Wallet
          </h1>
          <p className="text-xs text-neutral-400 mt-1 max-w-xl">
            All passes are encrypted and saved to your device’s local vault. Even if cellular data drops at crowded venues, your QR passes remain fully accessible for gate entry.
          </p>
        </div>

        {/* Offline Vault Indicator */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 bg-neutral-950 border border-neutral-800 rounded-2xl p-4 shrink-0">
          <div className="flex items-center gap-2">
            {isOfflineMode ? (
              <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
                <WifiOff className="w-4 h-4" />
              </div>
            ) : (
              <div className="w-8 h-8 rounded-xl bg-emerald-500/20 text-emerald-400 flex items-center justify-center">
                <Wifi className="w-4 h-4" />
              </div>
            )}
            <div>
              <p className="text-xs font-bold text-white">
                {isOfflineMode ? 'Offline Simulation Active' : 'Offline Vault Synced'}
              </p>
              <p className="text-[11px] text-neutral-400">
                {tickets.length} pass{tickets.length !== 1 ? 'es' : ''} stored in local cache
              </p>
            </div>
          </div>

          <button
            onClick={onToggleOffline}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors cursor-pointer ${
              isOfflineMode
                ? 'bg-amber-500 text-neutral-950 hover:bg-amber-400'
                : 'bg-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-700'
            }`}
          >
            {isOfflineMode ? 'Switch to Online' : 'Simulate Offline'}
          </button>
        </div>
      </div>

      {/* Segmented Navigation */}
      <div className="flex items-center gap-2 border-b border-neutral-800 pb-2">
        <button
          onClick={() => setActiveTab('passes')}
          className={`py-2 px-4 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
            activeTab === 'passes'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Active Passes ({activePasses.length})
        </button>
        <button
          onClick={() => setActiveTab('orders')}
          className={`py-2 px-4 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
            activeTab === 'orders'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Merchandise Pickups ({merchandiseOrders.length})
        </button>
        <button
          onClick={() => setActiveTab('settings')}
          className={`py-2 px-4 text-xs font-semibold rounded-xl transition-colors cursor-pointer ${
            activeTab === 'settings'
              ? 'bg-neutral-800 text-white'
              : 'text-neutral-400 hover:text-neutral-200'
          }`}
        >
          Security & Privacy
        </button>
      </div>

      {/* Active Passes View */}
      {activeTab === 'passes' && (
        <div className="space-y-6">
          {activePasses.length === 0 ? (
            <div className="p-12 text-center bg-neutral-900 border border-neutral-800 rounded-3xl">
              <QrCode className="w-12 h-12 text-neutral-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white">No Active Digital Passes</h3>
              <p className="text-xs text-neutral-400 mt-1 max-w-sm mx-auto">
                Explore upcoming events in Nairobi, Kigali, or Mombasa to book your passes via M-Pesa Paybill.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {activePasses.map((ticket) => (
                <div
                  key={ticket.id}
                  className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 hover:border-neutral-700 transition-all flex flex-col justify-between space-y-5"
                >
                  <div>
                    <div className="flex items-start justify-between">
                      <div>
                        <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                          {ticket.tierName}
                        </span>
                        <h3 className="text-lg font-bold text-white mt-1 leading-snug">
                          {ticket.eventTitle}
                        </h3>
                      </div>
                      <span className="font-mono text-xs text-neutral-400 bg-neutral-950 px-2.5 py-1 rounded-lg border border-neutral-800">
                        {ticket.ticketNumber}
                      </span>
                    </div>

                    <div className="mt-4 space-y-2 text-xs text-neutral-300">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                        <span className="truncate">{ticket.venueName} · {ticket.city}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Clock className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                        <span>{ticket.date} · Doors: {ticket.doorsOpen}</span>
                      </div>
                      {ticket.seatInfo && (
                        <div className="text-[11px] text-neutral-400 pt-1">
                          Zone: <strong className="text-neutral-200">{ticket.seatInfo}</strong>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="pt-4 border-t border-neutral-800 flex items-center justify-between">
                    <div>
                      <span className="text-[10px] text-neutral-500 block uppercase">M-Pesa Receipt</span>
                      <span className="font-mono text-xs font-bold text-emerald-400">
                        {ticket.mpesaReceiptNumber}
                      </span>
                    </div>

                    <button
                      onClick={() => onOpenTicketPass(ticket)}
                      className="py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                    >
                      <QrCode className="w-4 h-4" />
                      <span>Display QR Pass</span>
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Past/Used Passes */}
          {usedPasses.length > 0 && (
            <div className="mt-8 space-y-4">
              <h3 className="text-sm font-bold text-neutral-400 uppercase tracking-wider">
                Checked-In / Past Passes
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {usedPasses.map((ticket) => (
                  <div
                    key={ticket.id}
                    className="p-4 bg-neutral-950 border border-neutral-800/80 rounded-2xl flex items-center justify-between opacity-70"
                  >
                    <div>
                      <span className="text-xs font-semibold text-white">{ticket.eventTitle}</span>
                      <p className="text-[11px] text-neutral-500 mt-0.5">
                        {ticket.tierName} · {ticket.ticketNumber}
                      </p>
                    </div>
                    <div className="flex items-center gap-1.5 text-xs text-emerald-400 font-semibold">
                      <CheckCircle className="w-4 h-4" />
                      <span>Scanned at {ticket.checkedInAt}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Merchandise Orders View */}
      {activeTab === 'orders' && (
        <div className="space-y-4">
          {merchandiseOrders.length === 0 ? (
            <div className="p-12 text-center bg-neutral-900 border border-neutral-800 rounded-3xl">
              <Package className="w-12 h-12 text-neutral-600 mx-auto mb-3" />
              <h3 className="text-base font-bold text-white">No Merchandise Orders</h3>
              <p className="text-xs text-neutral-400 mt-1">
                Browse official GNet festival hoodies, smart wristbands, and safari caps.
              </p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {merchandiseOrders.map((ord) => (
                <div
                  key={ord.id}
                  className="p-5 bg-neutral-900 border border-neutral-800 rounded-2xl flex flex-col justify-between space-y-4"
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <h4 className="text-sm font-bold text-white">{ord.itemName}</h4>
                      <p className="text-xs text-neutral-400 mt-0.5">
                        Quantity: {ord.quantity} {ord.selectedSize ? `· Size: ${ord.selectedSize}` : ''}
                      </p>
                    </div>
                    <span className="font-mono text-xs font-bold text-emerald-400">
                      KES {ord.totalPriceKes.toLocaleString()}
                    </span>
                  </div>

                  <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <span className="text-neutral-500 block text-[10px]">Collection Code</span>
                      <span className="font-mono font-bold text-white text-sm">{ord.pickupCode}</span>
                    </div>
                    <div className="text-right">
                      <span className="text-neutral-500 block text-[10px]">M-Pesa Code</span>
                      <span className="font-mono text-emerald-400">{ord.mpesaReceiptNumber}</span>
                    </div>
                  </div>

                  <p className="text-[11px] text-neutral-500">
                    Show this collection code at the official GNet Merchandise Tent at the venue.
                  </p>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Security & Privacy View */}
      {activeTab === 'settings' && (
        <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">End-to-End Cryptographic Ticket Protection</h3>
              <p className="text-xs text-neutral-400">
                GNet East Africa Limited security protocol details
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
            <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-xl space-y-2">
              <h4 className="font-bold text-white">Anti-Passback Duplicate Detection</h4>
              <p className="text-neutral-400 leading-relaxed">
                Every ticket scan is signed with an HMAC token. If a ticket is shared or scanned twice across any gate, the turnstile automatically denies entry with an audible alert.
              </p>
            </div>

            <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-xl space-y-2">
              <h4 className="font-bold text-white">Offline Cryptographic Integrity</h4>
              <p className="text-neutral-400 leading-relaxed">
                Tickets contain localized checksum verification. Gate staff can scan and validate genuine tickets even during total cellular network blackout at the stadium.
              </p>
            </div>

            <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-xl space-y-2">
              <h4 className="font-bold text-white">Dynamic Watermark Screen Defense</h4>
              <p className="text-neutral-400 leading-relaxed">
                The digital pass features a microsecond ticking pulse bar that verifies the pass is active in real time, preventing unauthorized static screenshots and recordings.
              </p>
            </div>

            <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-xl space-y-2">
              <h4 className="font-bold text-white">Safaricom Daraja API Settlement</h4>
              <p className="text-neutral-400 leading-relaxed">
                All Paybill transactions resolve directly to GNet East Africa’s settlement account with real-time receipt token generation and zero third-party payment intermediary risk.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
