import React, { useState } from 'react';
import { MerchandiseItem } from '../types';
import { ShoppingBag, Check, ShieldCheck, Sparkles } from 'lucide-react';

interface MerchandiseViewProps {
  items: MerchandiseItem[];
  onSelectMerchToBuy: (item: MerchandiseItem, selectedSize?: string) => void;
}

export const MerchandiseView: React.FC<MerchandiseViewProps> = ({ items, onSelectMerchToBuy }) => {
  const [selectedSizes, setSelectedSizes] = useState<Record<string, string>>({
    'merch-hoodie-01': 'L',
  });
  const [selectedCategory, setSelectedCategory] = useState<string>('All');

  const categories = ['All', 'Apparel', 'Accessories', 'Wristbands', 'Vouchers'];

  const filteredItems = items.filter(
    (item) => selectedCategory === 'All' || item.category === selectedCategory
  );

  const handleSizeChange = (itemId: string, size: string) => {
    setSelectedSizes((prev) => ({ ...prev, [itemId]: size }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Merch Header Banner */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="text-emerald-400 font-bold uppercase tracking-wider">Official Event Store</span>
            <span>·</span>
            <span>Fast M-Pesa Checkout & Venue Express Pickup</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            GNet Festival Merchandise & RFID Smart Wristbands
          </h1>
          <p className="text-xs text-neutral-400 mt-1 max-w-xl">
            Order official event gear and preloaded cashless smart wristbands directly via M-Pesa. Collect instantly at the dedicated Fast-Track merchandise tent using your QR pickup token.
          </p>
        </div>

        {/* M-Pesa Paybill Trust Badge */}
        <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-2xl flex items-center gap-3 shrink-0">
          <div className="w-10 h-10 rounded-xl bg-[#00A859] text-white font-black text-xl flex items-center justify-center">
            M
          </div>
          <div>
            <span className="text-xs font-bold text-white block">Lipa na M-Pesa</span>
            <span className="text-[11px] text-neutral-400 font-mono">Paybill: 542800</span>
          </div>
        </div>
      </div>

      {/* Category Tabs */}
      <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-xl w-fit overflow-x-auto">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
              selectedCategory === cat
                ? 'bg-neutral-800 text-white shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredItems.map((item) => {
          const currentSize = selectedSizes[item.id] || (item.sizes ? item.sizes[0] : undefined);

          return (
            <div
              key={item.id}
              className="group bg-neutral-900 border border-neutral-800 rounded-3xl overflow-hidden hover:border-neutral-700 transition-all flex flex-col justify-between"
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden bg-neutral-950">
                <img
                  src={item.image}
                  alt={item.name}
                  className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute top-3 left-3">
                  <span className="text-[11px] font-bold px-2.5 py-1 rounded-md bg-neutral-950/80 backdrop-blur-md text-white border border-neutral-800">
                    {item.category}
                  </span>
                </div>
              </div>

              <div className="p-6 space-y-4 flex-1 flex flex-col justify-between">
                <div>
                  <h3 className="text-base font-bold text-white group-hover:text-emerald-400 transition-colors">
                    {item.name}
                  </h3>
                  <p className="text-xs text-neutral-400 mt-1 leading-relaxed">
                    {item.description}
                  </p>

                  {/* Size options if available */}
                  {item.sizes && (
                    <div className="mt-4">
                      <span className="text-[11px] font-medium text-neutral-400 block mb-1.5">
                        Select Size:
                      </span>
                      <div className="flex gap-1.5">
                        {item.sizes.map((s) => (
                          <button
                            key={s}
                            type="button"
                            onClick={() => handleSizeChange(item.id, s)}
                            className={`w-8 h-8 rounded-lg text-xs font-semibold flex items-center justify-center transition-colors cursor-pointer ${
                              currentSize === s
                                ? 'bg-emerald-500 text-neutral-950 font-bold'
                                : 'bg-neutral-950 border border-neutral-800 text-neutral-400 hover:text-white'
                            }`}
                          >
                            {s}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="pt-4 border-t border-neutral-800 flex items-center justify-between">
                  <div>
                    <span className="text-[10px] text-neutral-500 block uppercase">Price</span>
                    <span className="text-lg font-bold font-mono text-emerald-400">
                      KES {item.priceKes.toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => onSelectMerchToBuy(item, currentSize)}
                    className="py-2.5 px-4 bg-[#00A859] hover:bg-[#00924d] text-white font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                  >
                    <ShoppingBag className="w-3.5 h-3.5" />
                    <span>Buy with M-Pesa</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
