import React from 'react';
import { DeviceMode, UserRole } from '../types';
import { Bell, Smartphone, Monitor, ShieldCheck, Wifi, WifiOff } from 'lucide-react';

interface HeaderProps {
  currentTab: 'events' | 'tickets' | 'merch' | 'analytics' | 'scanner';
  onSelectTab: (tab: 'events' | 'tickets' | 'merch' | 'analytics' | 'scanner') => void;
  userRole: UserRole;
  onChangeRole: (role: UserRole) => void;
  deviceMode: DeviceMode;
  onChangeDeviceMode: (mode: DeviceMode) => void;
  isOffline: boolean;
  onToggleOffline: () => void;
  unreadCount: number;
  onOpenNotifications: () => void;
  onOpenSecurity: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onSelectTab,
  userRole,
  onChangeRole,
  deviceMode,
  onChangeDeviceMode,
  isOffline,
  onToggleOffline,
  unreadCount,
  onOpenNotifications,
  onOpenSecurity,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-neutral-900/95 backdrop-blur-md border-b border-neutral-800 transition-colors">
      {/* Utility Strip */}
      <div className="hidden lg:flex items-center justify-between px-6 py-1.5 text-xs border-b border-neutral-800/60 bg-neutral-950/60 text-neutral-400">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5 text-neutral-300">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            GNet M-Pesa Paybill: <strong className="text-white font-mono">542800</strong>
          </span>
          <span className="text-neutral-600">|</span>
          <span>East Africa Live Node: Nairobi (NBO-01)</span>
          <span className="text-neutral-600">|</span>
          <button 
            onClick={onOpenSecurity}
            className="flex items-center gap-1 hover:text-emerald-400 transition-colors text-neutral-400"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>AES-256 Encrypted Pass & Token Vault</span>
          </button>
        </div>

        <div className="flex items-center gap-4">
          {/* Offline Mode Switch */}
          <button
            onClick={onToggleOffline}
            className={`flex items-center gap-1.5 px-2 py-0.5 rounded transition-colors ${
              isOffline
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                : 'text-neutral-400 hover:text-white'
            }`}
            title="Simulate offline access without internet"
          >
            {isOffline ? <WifiOff className="w-3.5 h-3.5 text-amber-400" /> : <Wifi className="w-3.5 h-3.5 text-emerald-400" />}
            <span>{isOffline ? 'Offline Mode Active' : 'Online Sync'}</span>
          </button>

          {/* Device Viewport Selector */}
          <div className="flex items-center gap-1 bg-neutral-900 border border-neutral-800 rounded p-0.5">
            <button
              onClick={() => onChangeDeviceMode('desktop')}
              className={`p-1 rounded transition-colors ${
                deviceMode === 'desktop' ? 'bg-neutral-800 text-white' : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="Desktop View"
            >
              <Monitor className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => onChangeDeviceMode('ios')}
              className={`px-1.5 py-0.5 rounded text-[11px] font-medium transition-colors ${
                deviceMode === 'ios' ? 'bg-emerald-600 text-white' : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="iPhone 16 Pro View"
            >
              iOS
            </button>
            <button
              onClick={() => onChangeDeviceMode('android')}
              className={`px-1.5 py-0.5 rounded text-[11px] font-medium transition-colors ${
                deviceMode === 'android' ? 'bg-emerald-600 text-white' : 'text-neutral-400 hover:text-neutral-200'
              }`}
              title="Google Pixel 9 View"
            >
              Android
            </button>
          </div>

          {/* Role Switcher */}
          <div className="flex items-center gap-1">
            <span className="text-neutral-400">Role:</span>
            <select
              value={userRole}
              onChange={(e) => onChangeRole(e.target.value as UserRole)}
              className="bg-neutral-900 text-neutral-200 border border-neutral-700 rounded px-2 py-0.5 text-xs focus:outline-none focus:border-emerald-500 cursor-pointer font-medium"
            >
              <option value="attendee">Attendee</option>
              <option value="staff">Gate Staff / Scanner</option>
              <option value="organizer">Organizer / Admin</option>
            </select>
          </div>
        </div>
      </div>

      {/* Main Top Bar Contract: Zone 1 (Wordmark) - Zone 2 (4-5 Nav Links) - Zone 3 (1 Action/Control) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-8 h-16">
        {/* Zone 1: Brand Wordmark */}
        <div 
          onClick={() => onSelectTab('events')}
          className="flex items-center gap-2 cursor-pointer shrink-0"
        >
          <div className="w-8 h-8 rounded-lg bg-emerald-500 flex items-center justify-center font-black text-neutral-950 text-base shadow-sm">
            G
          </div>
          <div className="flex flex-col">
            <span className="text-lg font-bold tracking-tight text-white whitespace-nowrap leading-tight">
              GNet East Africa
            </span>
            <span className="text-[10px] tracking-wider text-emerald-400 font-medium uppercase">
              Live Ticketing Platform
            </span>
          </div>
        </div>

        {/* Zone 2: Navigation Links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium">
          <button
            onClick={() => onSelectTab('events')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'events'
                ? 'text-white border-b-2 border-emerald-500 font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Events
          </button>
          <button
            onClick={() => onSelectTab('tickets')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'tickets'
                ? 'text-white border-b-2 border-emerald-500 font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            My Wallet & Passes
          </button>
          <button
            onClick={() => onSelectTab('merch')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'merch'
                ? 'text-white border-b-2 border-emerald-500 font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Event Merchandise
          </button>
          <button
            onClick={() => onSelectTab('scanner')}
            className={`whitespace-nowrap transition-colors py-1 flex items-center gap-1.5 ${
              currentTab === 'scanner'
                ? 'text-white border-b-2 border-emerald-500 font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            <span>Gate Scanner</span>
            {userRole === 'staff' && (
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
            )}
          </button>
          <button
            onClick={() => onSelectTab('analytics')}
            className={`whitespace-nowrap transition-colors py-1 ${
              currentTab === 'analytics'
                ? 'text-white border-b-2 border-emerald-500 font-semibold'
                : 'text-neutral-400 hover:text-neutral-200'
            }`}
          >
            Venue Telemetry & Admin
          </button>
        </nav>

        {/* Zone 3: Actions (Notifications & Fast Action) */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenNotifications}
            className="relative p-2 rounded-lg bg-neutral-800 text-neutral-300 hover:text-white hover:bg-neutral-700 transition-colors"
            title="Push Notifications"
            aria-label="Push Notifications"
          >
            <Bell className="w-4 h-4" />
            {unreadCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-emerald-500 text-neutral-950 font-bold text-[10px] flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </button>

          <button
            onClick={() => onSelectTab('tickets')}
            className="px-3.5 py-2 text-xs font-semibold text-neutral-950 bg-emerald-400 rounded-lg hover:bg-emerald-300 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 shadow-sm"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span>Digital Passes</span>
          </button>
        </div>
      </div>

      {/* Mobile Sub-Navigation Bar for Small Screens */}
      <div className="md:hidden flex items-center justify-around border-t border-neutral-800 px-2 py-2 text-xs bg-neutral-950">
        <button
          onClick={() => onSelectTab('events')}
          className={`px-2 py-1 rounded font-medium ${
            currentTab === 'events' ? 'text-emerald-400 font-bold' : 'text-neutral-400'
          }`}
        >
          Events
        </button>
        <button
          onClick={() => onSelectTab('tickets')}
          className={`px-2 py-1 rounded font-medium ${
            currentTab === 'tickets' ? 'text-emerald-400 font-bold' : 'text-neutral-400'
          }`}
        >
          Tickets
        </button>
        <button
          onClick={() => onSelectTab('merch')}
          className={`px-2 py-1 rounded font-medium ${
            currentTab === 'merch' ? 'text-emerald-400 font-bold' : 'text-neutral-400'
          }`}
        >
          Merch
        </button>
        <button
          onClick={() => onSelectTab('scanner')}
          className={`px-2 py-1 rounded font-medium ${
            currentTab === 'scanner' ? 'text-emerald-400 font-bold' : 'text-neutral-400'
          }`}
        >
          Scanner
        </button>
        <button
          onClick={() => onSelectTab('analytics')}
          className={`px-2 py-1 rounded font-medium ${
            currentTab === 'analytics' ? 'text-emerald-400 font-bold' : 'text-neutral-400'
          }`}
        >
          Telemetry
        </button>
      </div>
    </header>
  );
};
