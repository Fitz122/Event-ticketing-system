import React, { useState } from 'react';
import { EventItem, TicketTier } from '../types';
import { Search, MapPin, Calendar, Users, ArrowUpRight, Flame } from 'lucide-react';

interface EventsViewProps {
  events: EventItem[];
  onSelectEventForBooking: (event: EventItem, tier?: TicketTier) => void;
}

export const EventsView: React.FC<EventsViewProps> = ({ events, onSelectEventForBooking }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedCity, setSelectedCity] = useState<string>('All');

  const categories = ['All', 'Music & Concerts', 'Tech & Innovation', 'Culture & Arts', 'Sports & Outdoors'];
  const cities = ['All', 'Nairobi', 'Kigali', 'Mombasa'];

  const filteredEvents = events.filter((ev) => {
    const matchesSearch =
      ev.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ev.venueName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      ev.city.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || ev.category === selectedCategory;
    const matchesCity = selectedCity === 'All' || ev.city === selectedCity;
    return matchesSearch && matchesCategory && matchesCity;
  });

  return (
    <div className="space-y-8 max-w-7xl mx-auto px-4 sm:px-6 py-6">
      {/* Hero Spotlight Section */}
      <div className="relative rounded-3xl overflow-hidden border border-neutral-800 bg-neutral-900">
        <div className="absolute inset-0 z-0">
          <img
            src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?auto=format&fit=crop&w=1600&q=80"
            alt="East Africa Live Events"
            className="w-full h-full object-cover opacity-25 filter brightness-75"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/70 to-transparent" />
        </div>

        <div className="relative z-10 p-6 sm:p-10 lg:p-12 max-w-3xl space-y-4">
          <div className="flex items-center gap-2 text-xs font-semibold text-emerald-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500" />
            <span>GNet East Africa Official Ticketing Hub</span>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight text-white leading-tight text-balance">
            Real-Time Ticketing & Smart Gate Access across East Africa.
          </h1>

          <p className="text-sm sm:text-base text-neutral-300 leading-relaxed">
            Instant Safaricom M-Pesa Paybill payments, automated cryptographic QR passes, offline-ready mobile wallet, and live venue capacity monitoring for Nairobi, Kigali, Kampala, and Mombasa.
          </p>

          <div className="pt-2 flex flex-wrap items-center gap-4 text-xs text-neutral-400">
            <span className="flex items-center gap-1.5 text-neutral-300">
              <strong className="text-emerald-400 font-mono font-bold">Paybill 542800</strong> · Safaricom M-Pesa Instant STK
            </span>
            <span>·</span>
            <span>Zero-wait Digital Turnstiles</span>
            <span>·</span>
            <span>Offline Pass Verification</span>
          </div>
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
        {/* Search */}
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search events, venues, or cities..."
            className="w-full pl-10 pr-4 py-2.5 bg-neutral-900 border border-neutral-800 rounded-xl text-sm text-white placeholder-neutral-500 focus:outline-none focus:border-emerald-500 transition-colors"
          />
        </div>

        {/* Interactive Segmented Filters */}
        <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
          {/* Category Tabs */}
          <div className="flex items-center gap-1 p-1 bg-neutral-900 border border-neutral-800 rounded-xl overflow-x-auto">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-lg whitespace-nowrap transition-colors cursor-pointer ${
                  selectedCategory === cat
                    ? 'bg-neutral-800 text-white shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          {/* City Selector */}
          <select
            value={selectedCity}
            onChange={(e) => setSelectedCity(e.target.value)}
            className="py-2 px-3 text-xs font-medium bg-neutral-900 border border-neutral-800 rounded-xl text-neutral-300 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            {cities.map((city) => (
              <option key={city} value={city}>
                {city === 'All' ? 'All Cities' : city}
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Events Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-6">
        {filteredEvents.map((event) => {
          const lowestPrice = Math.min(...event.tiers.map((t) => t.priceKes));
          const capacityPercent = Math.min(100, Math.round(((event.currentCheckedIn || 0) / event.capacityTotal) * 100));

          return (
            <div
              key={event.id}
              className="group bg-neutral-900/90 border border-neutral-800 rounded-2xl overflow-hidden hover:border-neutral-700 transition-all duration-200 flex flex-col"
            >
              {/* Event Image Banner */}
              <div className="relative aspect-[16/9] w-full overflow-hidden bg-neutral-950">
                <img
                  src={event.bannerImage}
                  alt={event.title}
                  className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-neutral-950 via-neutral-950/20 to-transparent" />

                {/* Demand & City indicator */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
                  <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-neutral-900/90 text-white backdrop-blur-sm border border-neutral-700/60">
                    {event.city}
                  </span>
                  {event.isHighDemand && (
                    <span className="text-xs font-bold px-2.5 py-1 rounded-md bg-amber-500/90 text-neutral-950 backdrop-blur-sm flex items-center gap-1 shadow-sm">
                      <Flame className="w-3.5 h-3.5 fill-current" />
                      Selling Fast
                    </span>
                  )}
                </div>

                {/* Venue Capacity Meter Overlay */}
                <div className="absolute bottom-3 left-3 right-3 bg-neutral-950/90 backdrop-blur-md border border-neutral-800/80 rounded-xl p-2.5">
                  <div className="flex items-center justify-between text-xs mb-1.5">
                    <span className="text-neutral-400 flex items-center gap-1">
                      <Users className="w-3.5 h-3.5 text-emerald-400" />
                      Live Gate Turnstiles
                    </span>
                    <span className="font-mono text-white font-semibold">
                      {event.currentCheckedIn.toLocaleString()} / {event.capacityTotal.toLocaleString()} ({capacityPercent}%)
                    </span>
                  </div>
                  <div className="w-full bg-neutral-800 h-1.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        capacityPercent > 90
                          ? 'bg-rose-500'
                          : capacityPercent > 75
                          ? 'bg-amber-400'
                          : 'bg-emerald-500'
                      }`}
                      style={{ width: `${capacityPercent}%` }}
                    />
                  </div>
                </div>
              </div>

              {/* Event Content */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-center gap-2 text-xs text-neutral-400 mb-1.5">
                    <Calendar className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>{event.date}</span>
                    <span>·</span>
                    <span>{event.time}</span>
                  </div>

                  <h3 className="text-xl font-bold text-white group-hover:text-emerald-400 transition-colors">
                    {event.title}
                  </h3>

                  <p className="text-xs text-neutral-400 mt-2 line-clamp-2 leading-relaxed">
                    {event.description}
                  </p>

                  <div className="flex items-center gap-1.5 text-xs text-neutral-400 mt-3">
                    <MapPin className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                    <span className="truncate">{event.venueName}</span>
                  </div>
                </div>

                {/* Pricing & Booking Row */}
                <div className="pt-4 border-t border-neutral-800/80 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] text-neutral-500 block">From</span>
                    <span className="text-base font-bold font-mono text-white">
                      KES {lowestPrice.toLocaleString()}
                    </span>
                  </div>

                  <button
                    onClick={() => onSelectEventForBooking(event)}
                    className="py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-semibold text-xs rounded-xl flex items-center gap-1.5 transition-colors cursor-pointer shadow-sm"
                  >
                    <span>Select Passes</span>
                    <ArrowUpRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
