import React, { useState } from 'react';
import { EventItem, MpesaTransaction, PushNotification, Ticket } from '../types';
import { storageService } from '../services/storageService';
import {
  Users,
  TrendingUp,
  CreditCard,
  Send,
  Radio,
  Clock,
  ArrowUpRight,
  ShieldCheck,
  CheckCircle,
} from 'lucide-react';

interface RealTimeAnalyticsViewProps {
  events: EventItem[];
  tickets: Ticket[];
  onBroadcastPushNotification: (notification: PushNotification) => void;
}

export const RealTimeAnalyticsView: React.FC<RealTimeAnalyticsViewProps> = ({
  events,
  tickets,
  onBroadcastPushNotification,
}) => {
  const [selectedEventId, setSelectedEventId] = useState<string>(events[0]?.id || '');
  const [broadcastTitle, setBroadcastTitle] = useState('');
  const [broadcastMessage, setBroadcastMessage] = useState('');
  const [broadcastType, setBroadcastType] = useState<'schedule' | 'gate' | 'weather' | 'emergency'>('schedule');
  const [broadcastSuccess, setBroadcastSuccess] = useState(false);

  const currentEvent = events.find((e) => e.id === selectedEventId) || events[0];
  const transactions: MpesaTransaction[] = storageService.getTransactions();

  // Metrics calculation
  const totalCapacity = currentEvent?.capacityTotal || 6500;
  const currentCheckedIn = currentEvent?.currentCheckedIn || 4890;
  const occupancyRate = Math.min(100, Math.round((currentCheckedIn / totalCapacity) * 100));

  const totalEventTickets = tickets.filter((t) => t.eventId === currentEvent?.id);
  const totalRevenueKes = transactions.reduce((sum, tx) => sum + tx.amountKes, 0);

  // Simulated Hourly Check-in Velocity
  const hourlyData = [
    { time: '15:00', count: 120, label: 'Gates Open' },
    { time: '16:00', count: 450, label: 'Early Wave' },
    { time: '17:00', count: 820, label: 'Opening Sets' },
    { time: '18:00', count: 1450, label: 'Sundown Peak' },
    { time: '19:00', count: 1250, label: 'Main Act Wave' },
    { time: '20:00', count: 800, label: 'Late Arrivals' },
  ];

  const handleBroadcast = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastTitle.trim() || !broadcastMessage.trim()) return;

    const newPush: PushNotification = {
      id: 'push-' + Date.now(),
      title: broadcastTitle,
      message: broadcastMessage,
      timestamp: 'Just now',
      type: broadcastType,
      eventId: currentEvent?.id,
      read: false,
    };

    onBroadcastPushNotification(newPush);
    setBroadcastTitle('');
    setBroadcastMessage('');
    setBroadcastSuccess(true);
    setTimeout(() => setBroadcastSuccess(false), 3000);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-6 space-y-8">
      {/* Header and Event Selector */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-neutral-400">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-emerald-400 font-bold uppercase tracking-wider">Live Telemetry Feed</span>
            <span>·</span>
            <span>Venue Gate Operations & M-Pesa Clearinghouse</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">
            Real-Time Venue Capacity & Analytics
          </h1>
          <p className="text-xs text-neutral-400 mt-1">
            Sub-second synchronization across all gate turnstiles, Daraja payment ledger, and attendee push notifications.
          </p>
        </div>

        {/* Event Filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-neutral-400 font-medium">Select Event:</span>
          <select
            value={selectedEventId}
            onChange={(e) => setSelectedEventId(e.target.value)}
            className="bg-neutral-950 text-white text-xs font-semibold px-4 py-2.5 rounded-xl border border-neutral-800 focus:outline-none focus:border-emerald-500 cursor-pointer"
          >
            {events.map((ev) => (
              <option key={ev.id} value={ev.id}>
                {ev.title} ({ev.city})
              </option>
            ))}
          </select>
        </div>
      </div>

      {/* Primary KPI Grid (4 Columns) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Capacity Metric */}
        <div className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Venue Occupancy</span>
            <Users className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-bold font-mono text-white">
            {occupancyRate}%
          </p>
          <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                occupancyRate > 90 ? 'bg-rose-500' : occupancyRate > 75 ? 'bg-amber-400' : 'bg-emerald-500'
              }`}
              style={{ width: `${occupancyRate}%` }}
            />
          </div>
          <span className="text-[11px] text-neutral-400 font-mono block pt-1">
            {currentCheckedIn.toLocaleString()} / {totalCapacity.toLocaleString()} inside
          </span>
        </div>

        {/* Check-In Velocity */}
        <div className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Check-in Velocity</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-bold font-mono text-white">
            42 <span className="text-xs font-normal text-neutral-400">entries/min</span>
          </p>
          <span className="text-xs text-emerald-400 font-medium flex items-center gap-1">
            <ArrowUpRight className="w-3.5 h-3.5" />
            +18% from previous hour
          </span>
          <span className="text-[11px] text-neutral-400 block">
            Peak expected between 18:30 - 19:30
          </span>
        </div>

        {/* Total Revenue in KES */}
        <div className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Settled M-Pesa Revenue</span>
            <CreditCard className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-2xl font-bold font-mono text-emerald-400 truncate">
            KES {totalRevenueKes.toLocaleString()}
          </p>
          <span className="text-xs text-neutral-300 font-mono">
            {transactions.length} successful STK settlements
          </span>
          <span className="text-[11px] text-neutral-400 block">
            Paybill: 542800 · Instant Daraja hook
          </span>
        </div>

        {/* Gate Security Integrity */}
        <div className="p-6 bg-neutral-900 border border-neutral-800 rounded-3xl space-y-2">
          <div className="flex items-center justify-between text-xs text-neutral-400">
            <span>Gate Fraud Rejection</span>
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-3xl font-bold font-mono text-white">
            100%
          </p>
          <span className="text-xs text-emerald-400 font-medium">
            3 Pass-Backs Intercepted
          </span>
          <span className="text-[11px] text-neutral-400 block">
            Zero duplicate entries allowed
          </span>
        </div>
      </div>

      {/* Two Column Layout: Velocity Graph & Gate Throughput */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Hourly Arrival Curve Chart (7 cols) */}
        <div className="lg:col-span-7 bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-bold text-white">Hourly Check-in Velocity Curve</h3>
              <p className="text-xs text-neutral-400 mt-0.5">Attendee influx wave breakdown by hour</p>
            </div>
            <span className="text-xs text-neutral-400 flex items-center gap-1 font-mono">
              <Clock className="w-3.5 h-3.5 text-emerald-400" />
              Live EAT Timezone
            </span>
          </div>

          {/* Bar Graph Simulation */}
          <div className="pt-6 pb-2">
            <div className="grid grid-cols-6 gap-3 items-end h-44">
              {hourlyData.map((d, i) => {
                const heightPercent = Math.min(100, (d.count / 1500) * 100);
                return (
                  <div key={i} className="flex flex-col items-center gap-2 group">
                    <span className="text-[10px] font-mono text-neutral-400 opacity-0 group-hover:opacity-100 transition-opacity">
                      {d.count}
                    </span>
                    <div className="w-full bg-neutral-950 rounded-xl h-36 flex items-end p-1">
                      <div
                        className="w-full bg-gradient-to-t from-emerald-600 to-teal-400 rounded-lg group-hover:brightness-110 transition-all duration-300"
                        style={{ height: `${heightPercent}%` }}
                      />
                    </div>
                    <span className="text-xs font-mono text-neutral-300">{d.time}</span>
                  </div>
                );
              })}
            </div>
          </div>

          <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl flex items-center justify-between text-xs">
            <span className="text-neutral-400">Peak Window Detected:</span>
            <strong className="text-white">18:00 - 19:30 EAT (1,450 entries/hr)</strong>
          </div>
        </div>

        {/* Gate Turnstile Breakdown (5 cols) */}
        <div className="lg:col-span-5 bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 space-y-6">
          <div>
            <h3 className="text-base font-bold text-white">Gate Turnstile Throughput</h3>
            <p className="text-xs text-neutral-400 mt-0.5">Real-time load balancing across venue entrances</p>
          </div>

          <div className="space-y-4">
            {currentEvent?.gates.map((gate, i) => {
              const gateLoads = [68, 84, 76, 32];
              const loadPercent = gateLoads[i % gateLoads.length];

              return (
                <div key={gate.id} className="p-3.5 bg-neutral-950 border border-neutral-800 rounded-2xl space-y-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">{gate.name}</span>
                    <span className="font-mono text-neutral-300 font-bold">{loadPercent}% capacity</span>
                  </div>
                  <div className="w-full bg-neutral-800 h-2 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        loadPercent > 80 ? 'bg-amber-400' : 'bg-emerald-500'
                      }`}
                      style={{ width: `${loadPercent}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[11px] text-neutral-500">
                    <span>Flow: {Math.round((gate.capacityPerHour * loadPercent) / 100)} / hr</span>
                    <span>Max: {gate.capacityPerHour}/hr</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Broadcast Push Notification to Attendees */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 space-y-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Radio className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">Broadcast Real-Time Push Notification</h3>
              <p className="text-xs text-neutral-400">
                Push instant venue notices, schedule changes, and gate alerts directly to attendees' mobile devices.
              </p>
            </div>
          </div>
        </div>

        <form onSubmit={handleBroadcast} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="sm:col-span-2">
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Notification Headline
              </label>
              <input
                type="text"
                required
                value={broadcastTitle}
                onChange={(e) => setBroadcastTitle(e.target.value)}
                placeholder="e.g. Stage 2 Set Time Moved to 21:30"
                className="w-full px-4 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1">
                Alert Category
              </label>
              <select
                value={broadcastType}
                onChange={(e) => setBroadcastType(e.target.value as any)}
                className="w-full px-3 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500 cursor-pointer"
              >
                <option value="schedule">Schedule Update</option>
                <option value="gate">Gate Advisory</option>
                <option value="weather">Weather & Venue Advisory</option>
                <option value="emergency">Emergency Announcement</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-medium text-neutral-300 mb-1">
              Broadcast Message Body
            </label>
            <textarea
              required
              rows={2}
              value={broadcastMessage}
              onChange={(e) => setBroadcastMessage(e.target.value)}
              placeholder="e.g. Due to sound check, headliner set will commence at 21:30 sharp. Food court remains open."
              className="w-full px-4 py-2.5 bg-neutral-950 border border-neutral-800 rounded-xl text-xs text-white focus:outline-none focus:border-emerald-500"
            />
          </div>

          <div className="flex items-center justify-between pt-2">
            {broadcastSuccess ? (
              <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1.5">
                <CheckCircle className="w-4 h-4" />
                Notification broadcast successfully to all registered attendees!
              </span>
            ) : (
              <span className="text-[11px] text-neutral-500">
                Pushes will trigger instant toast alerts on attendees' iOS & Android devices.
              </span>
            )}

            <button
              type="submit"
              className="py-2.5 px-5 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold text-xs rounded-xl flex items-center gap-2 transition-colors cursor-pointer shadow-sm"
            >
              <Send className="w-3.5 h-3.5" />
              <span>Broadcast to {currentCheckedIn.toLocaleString()} Attendees</span>
            </button>
          </div>
        </form>
      </div>

      {/* M-Pesa Settlement Ledger */}
      <div className="bg-neutral-900 border border-neutral-800 rounded-3xl p-6 sm:p-8 space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white">Safaricom M-Pesa Real-Time Settlement Ledger</h3>
          <span className="text-xs font-mono text-neutral-400">Paybill 542800</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-neutral-800 text-neutral-400">
                <th className="py-2.5 px-3">Receipt No</th>
                <th className="py-2.5 px-3">Account Ref</th>
                <th className="py-2.5 px-3">MSISDN</th>
                <th className="py-2.5 px-3">Description</th>
                <th className="py-2.5 px-3 text-right">Amount (KES)</th>
                <th className="py-2.5 px-3 text-right">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 font-mono">
              {transactions.map((tx) => (
                <tr key={tx.receiptNumber} className="hover:bg-neutral-950/40 transition-colors">
                  <td className="py-3 px-3 font-bold text-emerald-400">{tx.receiptNumber}</td>
                  <td className="py-3 px-3 text-neutral-300">{tx.accountNumber}</td>
                  <td className="py-3 px-3 text-neutral-400">{tx.phoneNumber}</td>
                  <td className="py-3 px-3 font-sans text-neutral-200 truncate max-w-xs">{tx.description}</td>
                  <td className="py-3 px-3 text-right font-bold text-white">
                    {tx.amountKes.toLocaleString()}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <span className="text-[10px] font-bold uppercase bg-emerald-950 text-emerald-400 border border-emerald-800 px-2 py-0.5 rounded">
                      {tx.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
