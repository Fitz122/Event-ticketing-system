import React, { useState } from 'react';
import { EventItem, TicketTier } from '../types';
import { X, Check, MapPin, Calendar, Clock, ShieldCheck, ArrowRight } from 'lucide-react';

interface EventDetailModalProps {
  event: EventItem | null;
  isOpen: boolean;
  onClose: () => void;
  onProceedToMpesa: (
    tier: TicketTier,
    quantity: number,
    attendeeName: string,
    attendeePhone: string,
    attendeeEmail: string
  ) => void;
}

export const EventDetailModal: React.FC<EventDetailModalProps> = ({
  event,
  isOpen,
  onClose,
  onProceedToMpesa,
}) => {
  const [selectedTierId, setSelectedTierId] = useState<string>('');
  const [quantity, setQuantity] = useState<number>(1);
  const [name, setName] = useState('Fitzgerald Omondi');
  const [phone, setPhone] = useState('0712 345 678');
  const [email, setEmail] = useState('fitzgeraldomondi@gmail.com');

  if (!isOpen || !event) return null;

  const currentTier = event.tiers.find((t) => t.id === (selectedTierId || event.tiers[0]?.id)) || event.tiers[0];
  const totalPrice = currentTier ? currentTier.priceKes * quantity : 0;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentTier || currentTier.available === 0) return;
    onProceedToMpesa(currentTier, quantity, name, phone, email);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-2xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Header with image */}
        <div className="relative h-44 shrink-0 bg-neutral-950 overflow-hidden">
          <img
            src={event.bannerImage}
            alt={event.title}
            className="w-full h-full object-cover brightness-75"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-neutral-900 via-neutral-900/60 to-transparent" />

          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-neutral-950/70 hover:bg-neutral-950 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="absolute bottom-4 left-6 right-6">
            <span className="text-xs font-semibold text-emerald-400 bg-emerald-950/80 px-2.5 py-0.5 rounded border border-emerald-800/80">
              {event.city} · {event.category}
            </span>
            <h2 className="text-2xl font-bold text-white mt-1.5 leading-tight">{event.title}</h2>
          </div>
        </div>

        {/* Scrollable Form Content */}
        <form onSubmit={handleSubmit} className="p-6 overflow-y-auto space-y-6">
          {/* Metadata quick stats */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-3 bg-neutral-950 border border-neutral-800 rounded-xl text-xs">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="text-neutral-500 block">Date</span>
                <span className="font-semibold text-white">{event.date}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="text-neutral-500 block">Doors Open</span>
                <span className="font-semibold text-white">{event.doorsOpen}</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-400" />
              <div>
                <span className="text-neutral-500 block">Venue</span>
                <span className="font-semibold text-white truncate">{event.venueName}</span>
              </div>
            </div>
          </div>

          {/* Ticket Tier Selection */}
          <div className="space-y-3">
            <label className="block text-xs font-bold text-neutral-300 uppercase tracking-wider">
              Select Pass Tier
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {event.tiers.map((tier) => {
                const isSelected = (selectedTierId || event.tiers[0].id) === tier.id;
                const isSoldOut = tier.available === 0;

                return (
                  <div
                    key={tier.id}
                    onClick={() => !isSoldOut && setSelectedTierId(tier.id)}
                    className={`p-4 rounded-2xl border transition-all cursor-pointer relative ${
                      isSoldOut
                        ? 'opacity-40 border-neutral-800 bg-neutral-950 cursor-not-allowed'
                        : isSelected
                        ? 'border-emerald-500 bg-emerald-950/20 shadow-md'
                        : 'border-neutral-800 bg-neutral-950/60 hover:border-neutral-700'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div>
                        <h4 className="font-bold text-white text-sm">{tier.name}</h4>
                        <span className="text-xs font-mono font-bold text-emerald-400">
                          KES {tier.priceKes.toLocaleString()}
                        </span>
                      </div>
                      {isSoldOut ? (
                        <span className="text-[10px] uppercase font-bold text-rose-400 bg-rose-950/60 px-2 py-0.5 rounded border border-rose-800">
                          Sold Out
                        </span>
                      ) : (
                        <span className="text-[10px] font-mono text-neutral-400">
                          {tier.available} left
                        </span>
                      )}
                    </div>

                    <ul className="mt-3 space-y-1 text-xs text-neutral-400">
                      {tier.perks.slice(0, 3).map((perk, i) => (
                        <li key={i} className="flex items-center gap-1.5 text-[11px]">
                          <Check className="w-3 h-3 text-emerald-400 shrink-0" />
                          <span className="truncate">{perk}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Quantity Selector & Attendee Info */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Pass Quantity
              </label>
              <div className="flex items-center gap-3">
                <button
                  type="button"
                  disabled={quantity <= 1}
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="w-10 h-10 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold flex items-center justify-center disabled:opacity-30 cursor-pointer"
                >
                  -
                </button>
                <span className="text-lg font-mono font-bold text-white w-10 text-center">
                  {quantity}
                </span>
                <button
                  type="button"
                  disabled={quantity >= 10 || quantity >= (currentTier?.available || 1)}
                  onClick={() => setQuantity((q) => q + 1)}
                  className="w-10 h-10 rounded-xl bg-neutral-800 hover:bg-neutral-700 text-white font-bold flex items-center justify-center disabled:opacity-30 cursor-pointer"
                >
                  +
                </button>
              </div>
            </div>

            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                M-Pesa Registered Phone
              </label>
              <input
                type="text"
                required
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="0712 345 678"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-xl text-white text-xs font-mono focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Attendee Full Name */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Primary Attendee Name
              </label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Full Name as on ID"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-xl text-white text-xs focus:border-emerald-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                Email for Backup Confirmation
              </label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="email@example.com"
                className="w-full px-3 py-2 bg-neutral-950 border border-neutral-700 rounded-xl text-white text-xs focus:border-emerald-500 focus:outline-none"
              />
            </div>
          </div>

          {/* Summary and Pay with M-Pesa CTA */}
          <div className="pt-4 border-t border-neutral-800 flex items-center justify-between">
            <div>
              <span className="text-xs text-neutral-400 block">Total Payable via M-Pesa</span>
              <span className="text-xl font-bold font-mono text-emerald-400">
                KES {totalPrice.toLocaleString()}
              </span>
            </div>

            <button
              type="submit"
              className="py-3 px-6 bg-[#00A859] hover:bg-[#00924d] text-white font-bold text-xs rounded-xl flex items-center gap-2 transition-colors shadow-lg shadow-[#00A859]/20 cursor-pointer"
            >
              <span>Pay with M-Pesa Paybill</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center justify-center gap-1.5 text-[11px] text-neutral-500">
            <ShieldCheck className="w-3.5 h-3.5 text-emerald-500" />
            <span>Automated QR pass issued instantly upon Safaricom M-Pesa confirmation.</span>
          </div>
        </form>
      </div>
    </div>
  );
};
