import React, { useEffect, useRef, useState } from 'react';
import QRCode from 'qrcode';
import { jsPDF } from 'jspdf';
import { Ticket } from '../types';
import { X, ShieldCheck, Download, Calendar, Printer, CheckCircle, WifiOff, FileText, Check } from 'lucide-react';

interface TicketPassModalProps {
  ticket: Ticket | null;
  isOpen: boolean;
  onClose: () => void;
  isOfflineMode?: boolean;
}

export const TicketPassModal: React.FC<TicketPassModalProps> = ({
  ticket,
  isOpen,
  onClose,
  isOfflineMode = false,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [securityTimer, setSecurityTimer] = useState(0);
  const [isExportingPdf, setIsExportingPdf] = useState(false);
  const [pdfExported, setPdfExported] = useState(false);

  // Security live pulse timer to prevent screenshot spoofing
  useEffect(() => {
    if (!isOpen) return;
    const interval = setInterval(() => {
      setSecurityTimer((prev) => (prev + 1) % 60);
    }, 1000);
    return () => clearInterval(interval);
  }, [isOpen]);

  // Generate QR Code
  useEffect(() => {
    if (!isOpen || !ticket || !canvasRef.current) return;

    QRCode.toCanvas(
      canvasRef.current,
      ticket.qrPayload || ticket.ticketNumber,
      {
        width: 260,
        margin: 1,
        color: {
          dark: '#0a0a0a',
          light: '#ffffff',
        },
        errorCorrectionLevel: 'H',
      },
      (error) => {
        if (error) console.error('QR code generation error:', error);
      }
    );
  }, [isOpen, ticket]);

  if (!isOpen || !ticket) return null;

  const handleDownloadCalendar = () => {
    const icsContent = [
      'BEGIN:VCALENDAR',
      'VERSION:2.0',
      'PRODID:-//GNet East Africa//Event Pass//EN',
      'BEGIN:VEVENT',
      `SUMMARY:${ticket.eventTitle} (${ticket.tierName})`,
      `DESCRIPTION:Your official digital ticket for ${ticket.eventTitle}. Venue: ${ticket.venueName}. Gate: Gate A/B. M-Pesa Ref: ${ticket.mpesaReceiptNumber}`,
      `LOCATION:${ticket.venueName}, ${ticket.city}`,
      `STATUS:CONFIRMED`,
      'END:VEVENT',
      'END:VCALENDAR',
    ].join('\r\n');

    const blob = new Blob([icsContent], { type: 'text/calendar;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${ticket.ticketNumber}-calendar.ics`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const handlePrint = () => {
    window.print();
  };

  const handleSavePass = () => {
    if (!canvasRef.current) return;
    const link = document.createElement('a');
    link.download = `${ticket.ticketNumber}-pass.png`;
    link.href = canvasRef.current.toDataURL();
    link.click();
  };

  const handleExportPdf = () => {
    if (!ticket || !canvasRef.current) return;
    setIsExportingPdf(true);

    try {
      // Create a standard A4 portrait PDF document (210mm x 297mm)
      const doc = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const qrDataUrl = canvasRef.current.toDataURL('image/png');

      // Outer Page Border / Clean Layout
      doc.setFillColor(15, 23, 42); // Dark slate header
      doc.rect(15, 15, 180, 28, 'F');

      // Brand Wordmark & Header
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(16);
      doc.text('GNet East Africa Limited', 22, 26);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(52, 211, 153); // Emerald accent
      doc.text('OFFICIAL DIGITAL EVENT TICKET & OFFLINE GATE PASS', 22, 33);

      doc.setTextColor(255, 255, 255);
      doc.setFontSize(9);
      doc.text(`PASS NO: ${ticket.ticketNumber}`, 145, 26);
      doc.text(`M-PESA REF: ${ticket.mpesaReceiptNumber}`, 145, 33);

      // Main Ticket Body Box
      doc.setFillColor(248, 250, 252); // Soft light background
      doc.rect(15, 43, 180, 180, 'F');
      doc.setDrawColor(203, 213, 225);
      doc.setLineWidth(0.4);
      doc.rect(15, 43, 180, 180, 'S');

      // Event Details
      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(18);
      // Support multi-line event title if long
      const splitTitle = doc.splitTextToSize(ticket.eventTitle, 165);
      doc.text(splitTitle, 22, 56);

      const titleHeightOffset = (splitTitle.length - 1) * 7;

      // Tier Badge
      doc.setFillColor(0, 168, 89); // Safaricom Green
      doc.roundedRect(22, 63 + titleHeightOffset, 55, 8, 2, 2, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.text(ticket.tierName.toUpperCase(), 25, 68.5 + titleHeightOffset);

      // Venue & Date Grid
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.setTextColor(100, 116, 139);
      doc.text('VENUE / LOCATION', 22, 80 + titleHeightOffset);
      doc.text('DATE & TIME', 110, 80 + titleHeightOffset);

      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text(`${ticket.venueName}, ${ticket.city}`, 22, 86 + titleHeightOffset);
      doc.text(`${ticket.date} · ${ticket.time}`, 110, 86 + titleHeightOffset);

      doc.setTextColor(100, 116, 139);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text('ATTENDEE NAME', 22, 97 + titleHeightOffset);
      doc.text('PHONE / SEAT INFO', 110, 97 + titleHeightOffset);

      doc.setTextColor(15, 23, 42);
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(10);
      doc.text(ticket.attendeeName, 22, 103 + titleHeightOffset);
      doc.text(`${ticket.attendeePhone} · ${ticket.seatInfo || 'General Access'}`, 110, 103 + titleHeightOffset);

      // Perforated Separation Line
      doc.setLineDashPattern([2, 2], 0);
      doc.setDrawColor(148, 163, 184);
      doc.line(22, 113 + titleHeightOffset, 188, 113 + titleHeightOffset);
      doc.setLineDashPattern([], 0); // Reset dash

      // Embed QR Code from Canvas
      const qrSize = 54;
      const qrX = 78;
      const qrY = 118 + titleHeightOffset;
      doc.addImage(qrDataUrl, 'PNG', qrX, qrY, qrSize, qrSize);

      // QR Instruction & Cryptographic Signature
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(9);
      doc.setTextColor(15, 23, 42);
      doc.text('PRESENT THIS QR CODE AT VENUE TURNSTILES', 105, 178 + titleHeightOffset, { align: 'center' });

      doc.setFont('courier', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(100, 116, 139);
      doc.text(`HMAC SIGNATURE: ${ticket.cryptoSignature || 'SHA256-AUTHENTICATED'}`, 105, 183 + titleHeightOffset, { align: 'center' });

      // Offline Validation & Safety Strip
      doc.setFillColor(241, 245, 249);
      doc.roundedRect(22, 188 + titleHeightOffset, 166, 18, 3, 3, 'F');
      doc.setFont('helvetica', 'bold');
      doc.setFontSize(8);
      doc.setTextColor(0, 168, 89);
      doc.text('✓ OFFLINE VALIDATION ENABLED', 26, 194 + titleHeightOffset);

      doc.setFont('helvetica', 'normal');
      doc.setFontSize(7.5);
      doc.setTextColor(71, 85, 105);
      doc.text(
        'This pass contains localized cryptographic integrity checks and is accepted by GNet turnstiles even in total network blackout.',
        26,
        199 + titleHeightOffset
      );
      doc.text(
        'Duplicate check-in prevention active: Each ticket can only be scanned once. Do not share your pass.',
        26,
        203 + titleHeightOffset
      );

      // Footer
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(8);
      doc.setTextColor(148, 163, 184);
      doc.text(
        `Generated on ${new Date().toLocaleDateString()} · GNet East Africa Ltd · Safaricom M-Pesa Paybill 542800`,
        105,
        235,
        { align: 'center' }
      );

      // Save PDF file
      doc.save(`${ticket.ticketNumber}-offline-backup.pdf`);
      setPdfExported(true);
      setTimeout(() => setPdfExported(false), 3000);
    } catch (err) {
      console.error('PDF export failed:', err);
    } finally {
      setIsExportingPdf(false);
    }
  };


  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Pass Top Banner */}
        <div className="bg-gradient-to-r from-emerald-600 to-teal-700 px-6 py-4 flex items-center justify-between text-white shrink-0">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-white animate-pulse" />
            <h2 className="font-bold text-sm tracking-tight uppercase">GNet Verified Digital Pass</h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-black/20 transition-colors cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Scrollable Ticket Card Body */}
        <div className="p-6 overflow-y-auto space-y-5">
          {/* Main Pass Container (Airline/Concert Ticket Style) */}
          <div className="bg-neutral-950 border border-neutral-800 rounded-2xl overflow-hidden shadow-inner relative">
            {/* Header info */}
            <div className="p-5 border-b border-neutral-800/80 bg-neutral-900/50">
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400">
                    {ticket.tierName}
                  </span>
                  <h3 className="text-lg font-bold text-white mt-0.5 leading-snug">{ticket.eventTitle}</h3>
                  <p className="text-xs text-neutral-400 mt-1">{ticket.venueName} · {ticket.city}</p>
                </div>
                <div className="text-right shrink-0">
                  <span className="text-[10px] text-neutral-500 font-mono">PASS NO.</span>
                  <p className="text-xs font-mono font-bold text-white">{ticket.ticketNumber}</p>
                </div>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-2 text-xs pt-3 border-t border-neutral-800/60">
                <div>
                  <span className="text-neutral-500">Event Date:</span>
                  <p className="font-semibold text-neutral-200">{ticket.date}</p>
                </div>
                <div>
                  <span className="text-neutral-500">Doors Open:</span>
                  <p className="font-semibold text-neutral-200">{ticket.doorsOpen}</p>
                </div>
                <div>
                  <span className="text-neutral-500">Attendee:</span>
                  <p className="font-semibold text-neutral-200 truncate">{ticket.attendeeName}</p>
                </div>
                <div>
                  <span className="text-neutral-500">M-Pesa Ref:</span>
                  <p className="font-mono font-semibold text-emerald-400">{ticket.mpesaReceiptNumber}</p>
                </div>
              </div>
            </div>

            {/* Middle Perforated Line */}
            <div className="relative py-2 flex items-center justify-between px-3">
              <div className="w-5 h-5 rounded-full bg-neutral-900 -ml-5.5 border-r border-neutral-800"></div>
              <div className="flex-1 border-b-2 border-dashed border-neutral-800 mx-2"></div>
              <div className="w-5 h-5 rounded-full bg-neutral-900 -mr-5.5 border-l border-neutral-800"></div>
            </div>

            {/* QR Code & Anti-Screenshot Live Security Watermark */}
            <div className="p-6 text-center space-y-4">
              <div className="inline-block p-3.5 bg-white rounded-2xl shadow-lg relative group">
                <canvas ref={canvasRef} className="block mx-auto" />
                {ticket.isCheckedIn && (
                  <div className="absolute inset-0 bg-neutral-950/90 rounded-2xl flex flex-col items-center justify-center p-4">
                    <CheckCircle className="w-12 h-12 text-emerald-400 mb-2" />
                    <span className="text-sm font-bold text-white uppercase tracking-wider">CHECKED IN</span>
                    <span className="text-[11px] text-neutral-400 font-mono mt-1">
                      {ticket.checkedInAt} · {ticket.checkedInGate}
                    </span>
                  </div>
                )}
              </div>

              {/* Dynamic Anti-Screenshot Watermark */}
              <div className="p-2.5 bg-neutral-900 border border-neutral-800 rounded-xl space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <span className="text-neutral-400 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                    Anti-Fraud Live Watermark
                  </span>
                  <span className="font-mono text-emerald-400 text-xs font-semibold">
                    {new Date().toLocaleTimeString()} :{securityTimer.toString().padStart(2, '0')}
                  </span>
                </div>
                {/* Visual pulse line */}
                <div className="w-full bg-neutral-800 h-1 rounded-full overflow-hidden">
                  <div
                    className="bg-emerald-500 h-full transition-all duration-1000 ease-linear rounded-full"
                    style={{ width: `${((securityTimer % 15) / 15) * 100}%` }}
                  />
                </div>
                <p className="text-[10px] text-neutral-500">
                  Scanners verify token cryptographic signature and live pulse to prevent duplicates.
                </p>
              </div>

              {/* Offline Readiness Badge */}
              <div className="flex items-center justify-center gap-2 text-xs py-1 text-emerald-400">
                {isOfflineMode ? (
                  <span className="flex items-center gap-1 text-amber-400">
                    <WifiOff className="w-3.5 h-3.5" />
                    <span>Offline Mode: Pass cached securely in browser storage</span>
                  </span>
                ) : (
                  <span className="flex items-center gap-1 text-emerald-400">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Offline Ready: Works without active cellular network</span>
                  </span>
                )}
              </div>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="space-y-2">
            {/* Primary Offline PDF Export Button */}
            <button
              onClick={handleExportPdf}
              disabled={isExportingPdf}
              className="w-full py-2.5 px-4 bg-emerald-500 hover:bg-emerald-400 text-neutral-950 font-bold rounded-xl text-xs flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-md disabled:opacity-50"
            >
              {pdfExported ? (
                <>
                  <Check className="w-4 h-4 text-neutral-950" />
                  <span>PDF Document Exported (Offline Backup Ready)</span>
                </>
              ) : isExportingPdf ? (
                <span>Generating Vector PDF...</span>
              ) : (
                <>
                  <FileText className="w-4 h-4 text-neutral-950" />
                  <span>Export Ticket as PDF Document (Offline Backup)</span>
                </>
              )}
            </button>

            {/* Secondary Actions Grid */}
            <div className="grid grid-cols-3 gap-2">
              <button
                onClick={handleSavePass}
                className="py-2 px-3 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                title="Save PNG image of ticket QR"
              >
                <Download className="w-3.5 h-3.5 text-neutral-300" />
                <span>Save PNG</span>
              </button>
              <button
                onClick={handleDownloadCalendar}
                className="py-2 px-3 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                title="Add to Google Calendar or Apple iCal"
              >
                <Calendar className="w-3.5 h-3.5 text-neutral-300" />
                <span>Add to Cal</span>
              </button>
              <button
                onClick={handlePrint}
                className="py-2 px-3 bg-neutral-800 hover:bg-neutral-700 text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors cursor-pointer"
                title="Print digital ticket"
              >
                <Printer className="w-3.5 h-3.5 text-neutral-300" />
                <span>Print Pass</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
