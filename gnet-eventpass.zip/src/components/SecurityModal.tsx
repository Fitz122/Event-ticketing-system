import React from 'react';
import { X, ShieldCheck, Lock, Key, Server, Cpu } from 'lucide-react';

interface SecurityModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SecurityModal: React.FC<SecurityModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-xl bg-neutral-900 border border-neutral-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="bg-neutral-950 p-6 border-b border-neutral-800 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-emerald-500/10 text-emerald-400 rounded-xl">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white">GNet End-to-End Encryption & Security Architecture</h2>
              <p className="text-xs text-neutral-400">East Africa Enterprise Event Trust Standard</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-neutral-400 hover:text-white hover:bg-neutral-800"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 overflow-y-auto space-y-5 text-xs">
          <div className="p-4 bg-emerald-950/20 border border-emerald-900/60 rounded-2xl flex items-start gap-3">
            <Lock className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-white">Tamper-Proof Ticket Payloads (AES-256 HMAC)</h3>
              <p className="text-neutral-300 mt-1 leading-relaxed">
                Every ticket generated on the platform is cryptographically signed using a SHA-256 HMAC hash. Any alteration of attendee details, seat class, or ticket ID produces an instant cryptographic signature mismatch during gate scans.
              </p>
            </div>
          </div>

          <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-2xl flex items-start gap-3">
            <Cpu className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-white">Zero-Knowledge Offline Validation</h3>
              <p className="text-neutral-400 mt-1 leading-relaxed">
                When mobile reception drops at high-density venues (such as KICC or BK Arena), turnstiles run local client-side verification against pre-cached cryptographic keys, rejecting fake or duplicated tickets without requiring live internet.
              </p>
            </div>
          </div>

          <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-2xl flex items-start gap-3">
            <Key className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-white">Dynamic Anti-Screenshot Watermark</h3>
              <p className="text-neutral-400 mt-1 leading-relaxed">
                Static screenshots or recorded videos cannot be passed between attendees at gate entrances. The digital pass displays a high-frequency synchronized visual time pulse verified by turnstile cameras.
              </p>
            </div>
          </div>

          <div className="p-4 bg-neutral-950 border border-neutral-800 rounded-2xl flex items-start gap-3">
            <Server className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <h3 className="font-bold text-white">Safaricom Daraja API PCI-DSS Encrypted Handshake</h3>
              <p className="text-neutral-400 mt-1 leading-relaxed">
                M-Pesa Paybill #542800 queries interact directly with Safaricom's TLS 1.3 encrypted endpoints. User mobile PINs are exclusively entered into the hardware SIM Toolkit, never logged or stored on any intermediate server.
              </p>
            </div>
          </div>
        </div>

        <div className="p-4 bg-neutral-950 border-t border-neutral-800 text-center">
          <button
            onClick={onClose}
            className="w-full py-2.5 bg-neutral-800 hover:bg-neutral-700 text-white font-semibold rounded-xl text-xs transition-colors cursor-pointer"
          >
            Acknowledge & Close
          </button>
        </div>
      </div>
    </div>
  );
};
