import React from 'react';
import { DeviceMode } from '../types';
import { Wifi, BatteryMedium } from 'lucide-react';

interface MobileFrameProps {
  deviceMode: DeviceMode;
  children: React.ReactNode;
}

export const MobileFrame: React.FC<MobileFrameProps> = ({ deviceMode, children }) => {
  if (deviceMode === 'desktop') {
    return <>{children}</>;
  }

  const isIos = deviceMode === 'ios';

  return (
    <div className="py-6 px-2 flex justify-center items-center min-h-[calc(100vh-64px)] bg-neutral-950/80">
      {/* Device Chassis */}
      <div
        className={`relative w-full max-w-[410px] h-[840px] bg-neutral-900 rounded-[50px] shadow-[0_0_60px_rgba(0,0,0,0.9)] p-3 border-4 ${
          isIos ? 'border-neutral-700' : 'border-neutral-800'
        } flex flex-col overflow-hidden transition-all duration-300`}
      >
        {/* Device Status Bar */}
        <div className="relative z-30 pt-2 px-6 flex items-center justify-between text-white text-xs select-none">
          <span className="font-semibold text-[13px] font-mono">
            {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </span>

          {/* Dynamic Island (iOS) or Hole Punch (Android) */}
          {isIos ? (
            <div className="w-24 h-6 bg-black rounded-full flex items-center justify-center gap-1.5 px-2">
              <div className="w-2.5 h-2.5 rounded-full bg-neutral-900 border border-neutral-700" />
              <div className="w-2 h-2 rounded-full bg-emerald-500/40" />
            </div>
          ) : (
            <div className="w-3.5 h-3.5 bg-black rounded-full border border-neutral-800" />
          )}

          <div className="flex items-center gap-1.5 text-neutral-300">
            <span className="text-[10px] font-mono font-bold">5G</span>
            <Wifi className="w-3.5 h-3.5" />
            <BatteryMedium className="w-4 h-4" />
          </div>
        </div>

        {/* Device Screen Content Viewport */}
        <div className="relative flex-1 bg-neutral-950 rounded-[40px] overflow-y-auto mt-1 flex flex-col">
          {children}
        </div>

        {/* Bottom Home Indicator */}
        <div className="pt-2 flex justify-center">
          <div
            className={`h-1 rounded-full ${
              isIos ? 'w-32 bg-neutral-400' : 'w-24 bg-neutral-600'
            }`}
          />
        </div>
      </div>
    </div>
  );
};
