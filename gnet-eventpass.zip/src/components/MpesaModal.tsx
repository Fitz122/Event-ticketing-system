import React, { useState } from 'react';
import { CryptoService } from '../services/cryptoService';
import { audioService } from '../services/audioService';
import confetti from 'canvas-confetti';
import { CheckCircle2, Loader2, Phone, X, ShieldAlert, ArrowRight, Copy, Check } from 'lucide-react';

interface MpesaModalProps {
  isOpen: boolean;
  onClose: () => void;
  title: string;
  accountReference: string;
  amountKes: number;
  description: string;
  onPaymentSuccess: (receiptNumber: string, phone: string) => void;
}

export const MpesaModal: React.FC<MpesaModalProps> = ({
  isOpen,
  onClose,
  title,
  accountReference,
  amountKes,
  description,
  onPaymentSuccess,
}) => {
  const [phoneNumber, setPhoneNumber] = useState('0712 345 678');
  const [mode, setMode] = useState<'stk' | 'manual'>('stk');
  const [stage, setStage] = useState<'input' | 'pushing' | 'pin_prompt' | 'processing' | 'success'>('input');
  const [pin, setPin] = useState('');
  const [receiptNumber, setReceiptNumber] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  const startStkPush = (e: React.FormEvent) => {
    e.preventDefault();
    if (!phoneNumber || phoneNumber.length < 9) return;

    setStage('pushing');
    setTimeout(() => {
      setStage('pin_prompt');
      audioService.playValidCheckIn();
    }, 1200);
  };

  const handleConfirmPin = (e: React.FormEvent) => {
    e.preventDefault();
    setStage('processing');

    setTimeout(() => {
      const generatedReceipt = CryptoService.generateMpesaReceipt();
      setReceiptNumber(generatedReceipt);
      setStage('success');
      audioService.playVipFanfare();

      try {
        confetti({
          particleCount: 60,
          spread: 70,
          origin: { y: 0.6 },
        });
      } catch {
        // Ignore confetti error
      }

      setTimeout(() => {
        onPaymentSuccess(generatedReceipt, phoneNumber);
      }, 1800);
    }, 1400);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="relative w-full max-w-md bg-neutral-900 border border-neutral-800 rounded-2xl shadow-2xl overflow-hidden">
        {/* Header with Safaricom M-Pesa Signature */}
        <div className="bg-[#00A859] px-6 py-4 flex items-center justify-between text-white">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-white text-[#00A859] font-black text-xl flex items-center justify-center shadow-inner">
              M
            </div>
            <div>
              <h2 className="font-bold text-base tracking-tight leading-tight">Lipa na M-PESA</h2>
              <p className="text-xs text-emerald-100 font-medium">GNet East Africa Limited · Paybill 542800</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-full text-white/80 hover:text-white hover:bg-black/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6">
          {/* Order Summary Strip */}
          <div className="bg-neutral-950 border border-neutral-800/80 rounded-xl p-4 mb-5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-xs text-neutral-400 font-medium">Checkout Item</p>
                <p className="text-sm font-semibold text-white mt-0.5">{title}</p>
                <p className="text-xs text-neutral-500 mt-0.5">{description}</p>
              </div>
              <div className="text-right">
                <p className="text-xs text-neutral-400 font-medium">Total Payable</p>
                <p className="text-lg font-bold font-mono text-emerald-400">
                  KES {amountKes.toLocaleString()}
                </p>
              </div>
            </div>
            <div className="mt-3 pt-3 border-t border-neutral-800/80 flex items-center justify-between text-xs">
              <span className="text-neutral-400">Account Reference:</span>
              <span className="font-mono font-semibold text-white">{accountReference}</span>
            </div>
          </div>

          {/* Mode Tabs */}
          {stage === 'input' && (
            <div className="flex items-center p-1 bg-neutral-950 border border-neutral-800 rounded-lg mb-5">
              <button
                type="button"
                onClick={() => setMode('stk')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                  mode === 'stk'
                    ? 'bg-[#00A859] text-white shadow'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                Instant STK Push
              </button>
              <button
                type="button"
                onClick={() => setMode('manual')}
                className={`flex-1 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                  mode === 'manual'
                    ? 'bg-[#00A859] text-white shadow'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                Manual Paybill
              </button>
            </div>
          )}

          {/* STK Push Input Stage */}
          {stage === 'input' && mode === 'stk' && (
            <form onSubmit={startStkPush} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-neutral-300 mb-1.5">
                  M-Pesa Registered Phone Number (Kenya/East Africa)
                </label>
                <div className="relative">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-neutral-500">
                    <Phone className="w-4 h-4 text-[#00A859]" />
                  </div>
                  <input
                    type="text"
                    required
                    value={phoneNumber}
                    onChange={(e) => setPhoneNumber(e.target.value)}
                    placeholder="e.g. 0712 345 678 or 254712345678"
                    className="w-full pl-9 pr-3 py-2.5 bg-neutral-950 border border-neutral-700 rounded-xl text-white text-sm font-mono focus:outline-none focus:border-[#00A859] transition-colors"
                  />
                </div>
                <p className="text-[11px] text-neutral-500 mt-1.5">
                  An instant payment prompt will appear on this phone screen.
                </p>
              </div>

              <button
                type="submit"
                className="w-full py-3 px-4 bg-[#00A859] hover:bg-[#00924d] text-white font-semibold rounded-xl transition-colors flex items-center justify-center gap-2 shadow-lg shadow-[#00A859]/20 cursor-pointer"
              >
                <span>Send M-Pesa STK Prompt</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </form>
          )}

          {/* Manual Paybill Instructions */}
          {stage === 'input' && mode === 'manual' && (
            <div className="space-y-3">
              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl space-y-2 text-xs">
                <div className="flex items-center justify-between py-1 border-b border-neutral-800/60">
                  <span className="text-neutral-400">1. Paybill Business No:</span>
                  <div className="flex items-center gap-2">
                    <strong className="text-white font-mono text-sm">542800</strong>
                    <button
                      onClick={() => handleCopy('542800', 'paybill')}
                      className="p-1 hover:text-emerald-400 text-neutral-500"
                    >
                      {copiedField === 'paybill' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <div className="flex items-center justify-between py-1 border-b border-neutral-800/60">
                  <span className="text-neutral-400">2. Account No:</span>
                  <div className="flex items-center gap-2">
                    <strong className="text-white font-mono text-sm">{accountReference}</strong>
                    <button
                      onClick={() => handleCopy(accountReference, 'acc')}
                      className="p-1 hover:text-emerald-400 text-neutral-500"
                    >
                      {copiedField === 'acc' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>
                <div className="flex items-center justify-between py-1">
                  <span className="text-neutral-400">3. Amount:</span>
                  <strong className="text-emerald-400 font-mono text-sm">KES {amountKes.toLocaleString()}</strong>
                </div>
              </div>

              <button
                type="button"
                onClick={() => {
                  setStage('pushing');
                  setTimeout(() => {
                    const simReceipt = CryptoService.generateMpesaReceipt();
                    setReceiptNumber(simReceipt);
                    setStage('success');
                    audioService.playVipFanfare();
                    setTimeout(() => onPaymentSuccess(simReceipt, phoneNumber), 1600);
                  }, 1200);
                }}
                className="w-full py-2.5 px-4 bg-neutral-800 hover:bg-neutral-700 text-white text-xs font-semibold rounded-xl transition-colors cursor-pointer"
              >
                I have completed Paybill Payment (Verify Receipt)
              </button>
            </div>
          )}

          {/* STK Sending Animation */}
          {stage === 'pushing' && (
            <div className="py-8 text-center space-y-3">
              <Loader2 className="w-10 h-10 animate-spin text-[#00A859] mx-auto" />
              <h3 className="font-semibold text-white text-base">Requesting Safaricom STK Push...</h3>
              <p className="text-xs text-neutral-400 max-w-xs mx-auto">
                Connecting to Safaricom Daraja API gateway. Handshake with MSISDN {phoneNumber}...
              </p>
            </div>
          )}

          {/* SIM Toolkit PIN Prompt Simulator (Phone Modal on Screen) */}
          {stage === 'pin_prompt' && (
            <div className="space-y-4">
              <div className="bg-neutral-950 border-2 border-emerald-500/80 rounded-2xl p-4 shadow-xl">
                <div className="flex items-center gap-2 mb-2 pb-2 border-b border-neutral-800">
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <span className="text-xs font-bold text-white uppercase tracking-wider">SIM Toolkit · Safaricom</span>
                </div>
                <p className="text-xs text-neutral-200 font-mono leading-relaxed">
                  Do you want to pay <strong className="text-white">KES {amountKes.toLocaleString()}</strong> to{' '}
                  <strong className="text-emerald-400">GNET EAST AFRICA LIMITED</strong> Paybill 542800 Account{' '}
                  <strong className="text-white">{accountReference}</strong>?
                </p>

                <form onSubmit={handleConfirmPin} className="mt-4 space-y-3">
                  <div>
                    <label className="block text-[11px] text-neutral-400 mb-1">Enter 4-Digit M-Pesa PIN:</label>
                    <input
                      type="password"
                      maxLength={4}
                      autoFocus
                      required
                      value={pin}
                      onChange={(e) => setPin(e.target.value)}
                      placeholder="••••"
                      className="w-full text-center text-xl tracking-widest py-2 bg-neutral-900 border border-neutral-700 rounded-lg text-white font-mono focus:border-emerald-500 focus:outline-none"
                    />
                  </div>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setStage('input')}
                      className="flex-1 py-2 text-xs font-semibold text-neutral-400 hover:text-white bg-neutral-800 rounded-lg cursor-pointer"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="flex-1 py-2 text-xs font-bold text-neutral-950 bg-[#00A859] hover:bg-[#00924d] rounded-lg transition-colors cursor-pointer"
                    >
                      Authorize Payment
                    </button>
                  </div>
                </form>
              </div>

              <div className="flex items-center justify-center gap-1.5 text-[11px] text-neutral-500">
                <ShieldAlert className="w-3.5 h-3.5 text-neutral-400" />
                <span>Simulated Secure SIM Toolkit Environment</span>
              </div>
            </div>
          )}

          {/* Processing Confirmation */}
          {stage === 'processing' && (
            <div className="py-8 text-center space-y-3">
              <Loader2 className="w-10 h-10 animate-spin text-emerald-400 mx-auto" />
              <h3 className="font-semibold text-white text-base">Processing M-Pesa Authorization...</h3>
              <p className="text-xs text-neutral-400">Validating ledger entry and generating tamper-proof ticket token...</p>
            </div>
          )}

          {/* Payment Success Receipt */}
          {stage === 'success' && (
            <div className="space-y-4 py-2 text-center animate-in zoom-in-95 duration-200">
              <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                <CheckCircle2 className="w-7 h-7" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Payment Confirmed!</h3>
                <p className="text-xs text-neutral-400 mt-0.5">Safaricom M-Pesa Receipt Code</p>
                <p className="text-xl font-bold font-mono text-[#00A859] tracking-wider mt-1">{receiptNumber}</p>
              </div>

              <div className="p-3 bg-neutral-950 border border-neutral-800 rounded-xl text-left text-xs font-mono text-neutral-300 space-y-1">
                <p className="text-[10px] text-neutral-500 uppercase">Incoming Safaricom SMS:</p>
                <p className="text-neutral-300 leading-snug">
                  {receiptNumber} Confirmed. Ksh{amountKes.toLocaleString()}.00 sent to GNET EAST AFRICA LIMITED on {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}.
                </p>
              </div>
              <p className="text-xs text-neutral-400">Activating your digital pass in wallet...</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
