export type UserRole = 'attendee' | 'staff' | 'organizer';

export type DeviceMode = 'desktop' | 'ios' | 'android';

export interface TicketTier {
  id: string;
  name: string; // e.g., 'Early Bird', 'Regular', 'VIP Pass', 'VVIP Lounge'
  priceKes: number;
  available: number;
  total: number;
  perks: string[];
  gateAccess: string[];
}

export interface EventItem {
  id: string;
  title: string;
  tagline: string;
  category: 'Music & Concerts' | 'Tech & Innovation' | 'Culture & Arts' | 'Sports & Outdoors' | 'Corporate & Expo';
  venueName: string;
  city: 'Nairobi' | 'Mombasa' | 'Kigali' | 'Kampala' | 'Dar es Salaam';
  venueAddress: string;
  capacityTotal: number;
  currentCheckedIn: number;
  date: string;
  time: string;
  doorsOpen: string;
  bannerImage: string;
  description: string;
  tiers: TicketTier[];
  gates: { id: string; name: string; capacityPerHour: number }[];
  isHighDemand?: boolean;
}

export interface Ticket {
  id: string;
  ticketNumber: string; // e.g. GNET-2026-8941
  eventId: string;
  eventTitle: string;
  tierId: string;
  tierName: string;
  venueName: string;
  city: string;
  date: string;
  time: string;
  doorsOpen: string;
  seatInfo?: string;
  priceKes: number;
  attendeeName: string;
  attendeePhone: string;
  attendeeEmail: string;
  mpesaReceiptNumber: string;
  purchasedAt: string;
  isCheckedIn: boolean;
  checkedInAt?: string;
  checkedInGate?: string;
  checkedInByStaffId?: string;
  qrPayload: string;
  cryptoSignature: string;
  isOfflineCached: boolean;
}

export interface CheckInLogEntry {
  id: string;
  ticketNumber: string;
  attendeeName: string;
  eventTitle: string;
  tierName: string;
  gate: string;
  timestamp: string;
  status: 'valid' | 'duplicate_rejected' | 'invalid_token' | 'offline_verified';
  staffName: string;
}

export interface MerchandiseItem {
  id: string;
  name: string;
  category: 'Apparel' | 'Accessories' | 'Wristbands' | 'Vouchers';
  priceKes: number;
  stock: number;
  image: string;
  description: string;
  sizes?: string[];
}

export interface MerchandiseOrder {
  id: string;
  orderNumber: string;
  itemId: string;
  itemName: string;
  quantity: number;
  selectedSize?: string;
  totalPriceKes: number;
  mpesaReceiptNumber: string;
  orderedAt: string;
  pickupCode: string;
  isCollected: boolean;
}

export interface PushNotification {
  id: string;
  title: string;
  message: string;
  timestamp: string;
  type: 'schedule' | 'gate' | 'weather' | 'payment' | 'emergency';
  eventId?: string;
  read: boolean;
  actionUrl?: string;
}

export interface MpesaTransaction {
  receiptNumber: string;
  accountNumber: string;
  phoneNumber: string;
  amountKes: number;
  timestamp: string;
  status: 'COMPLETED' | 'PENDING' | 'FAILED';
  description: string;
}
