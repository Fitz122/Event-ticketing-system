import React, { useState, useEffect } from 'react';
import { DeviceMode, EventItem, MerchandiseItem, MerchandiseOrder, PushNotification, Ticket, TicketTier, UserRole } from './types';
import { storageService } from './services/storageService';
import { CryptoService } from './services/cryptoService';
import { audioService } from './services/audioService';

import { Header } from './components/Header';
import { MobileFrame } from './components/MobileFrame';
import { EventsView } from './components/EventsView';
import { EventDetailModal } from './components/EventDetailModal';
import { MpesaModal } from './components/MpesaModal';
import { TicketPassModal } from './components/TicketPassModal';
import { UserDashboard } from './components/UserDashboard';
import { GateScannerView } from './components/GateScannerView';
import { RealTimeAnalyticsView } from './components/RealTimeAnalyticsView';
import { MerchandiseView } from './components/MerchandiseView';
import { PushNotificationCenter } from './components/PushNotificationCenter';
import { SecurityModal } from './components/SecurityModal';

import { Bell, X, WifiOff } from 'lucide-react';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'events' | 'tickets' | 'merch' | 'analytics' | 'scanner'>('events');
  const [userRole, setUserRole] = useState<UserRole>('attendee');
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('desktop');
  const [isOffline, setIsOffline] = useState<boolean>(false);

  // Core Data State
  const [events, setEvents] = useState<EventItem[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [merchandise, setMerchandise] = useState<MerchandiseItem[]>([]);
  const [merchandiseOrders, setMerchandiseOrders] = useState<MerchandiseOrder[]>([]);
  const [notifications, setNotifications] = useState<PushNotification[]>([]);

  // Modals State
  const [selectedEventForBooking, setSelectedEventForBooking] = useState<EventItem | null>(null);
  const [bookingTier, setBookingTier] = useState<TicketTier | null>(null);
  const [bookingQty, setBookingQty] = useState<number>(1);
  const [bookingAttendee, setBookingAttendee] = useState({ name: '', phone: '', email: '' });

  // M-Pesa Modal State
  const [isMpesaModalOpen, setIsMpesaModalOpen] = useState(false);
  const [mpesaPaymentMeta, setMpesaPaymentMeta] = useState<{
    title: string;
    accountReference: string;
    amountKes: number;
    description: string;
    type: 'ticket' | 'merch';
    merchItem?: MerchandiseItem;
    merchSize?: string;
  } | null>(null);

  // Digital Ticket Pass Modal
  const [selectedTicketForPass, setSelectedTicketForPass] = useState<Ticket | null>(null);

  // Drawer & Notice Modals
  const [isNotificationCenterOpen, setIsNotificationCenterOpen] = useState(false);
  const [isSecurityModalOpen, setIsSecurityModalOpen] = useState(false);
  const [activeToastPush, setActiveToastPush] = useState<PushNotification | null>(null);

  // Initial Data Load
  useEffect(() => {
    setEvents(storageService.getEvents());
    setTickets(storageService.getTickets());
    setMerchandise(storageService.getMerchandise());
    setMerchandiseOrders(storageService.getMerchandiseOrders());
    setNotifications(storageService.getNotifications());
    setIsOffline(storageService.isOfflineSimulated());
  }, []);

  // Sync state helper
  const reloadData = () => {
    setEvents(storageService.getEvents());
    setTickets(storageService.getTickets());
    setMerchandiseOrders(storageService.getMerchandiseOrders());
  };

  const handleToggleOffline = () => {
    const nextVal = !isOffline;
    setIsOffline(nextVal);
    storageService.setOfflineSimulated(nextVal);
  };

  const handleRoleChange = (role: UserRole) => {
    setUserRole(role);
    if (role === 'staff') {
      setCurrentTab('scanner');
    } else if (role === 'organizer') {
      setCurrentTab('analytics');
    } else {
      setCurrentTab('events');
    }
  };

  // Push notification trigger
  const handleIncomingPushNotification = (notif: PushNotification) => {
    storageService.addNotification(notif);
    setNotifications(storageService.getNotifications());
    setActiveToastPush(notif);
    audioService.playValidCheckIn();

    setTimeout(() => {
      setActiveToastPush((current) => (current?.id === notif.id ? null : current));
    }, 6000);
  };

  // Checkout flow: Ticket selection
  const handleProceedToMpesa = (
    tier: TicketTier,
    quantity: number,
    attendeeName: string,
    attendeePhone: string,
    attendeeEmail: string
  ) => {
    if (!selectedEventForBooking) return;
    setBookingTier(tier);
    setBookingQty(quantity);
    setBookingAttendee({ name: attendeeName, phone: attendeePhone, email: attendeeEmail });

    const totalAmount = tier.priceKes * quantity;
    const tempTicketCode = `GNET-${new Date().getFullYear()}-${Math.floor(1000 + Math.random() * 9000)}`;

    setMpesaPaymentMeta({
      title: `${quantity}x ${tier.name} · ${selectedEventForBooking.title}`,
      accountReference: tempTicketCode,
      amountKes: totalAmount,
      description: `GNet Live Ticketing - Gate: ${tier.gateAccess[0] || 'Main'}`,
      type: 'ticket',
    });

    setIsMpesaModalOpen(true);
  };

  // Checkout flow: Merch selection
  const handleSelectMerchToBuy = (item: MerchandiseItem, selectedSize?: string) => {
    const pickupOrderNumber = `GNET-MRCH-${Math.floor(1000 + Math.random() * 9000)}`;
    setMpesaPaymentMeta({
      title: item.name,
      accountReference: pickupOrderNumber,
      amountKes: item.priceKes,
      description: `Official Event Merchandise · Size: ${selectedSize || 'Standard'}`,
      type: 'merch',
      merchItem: item,
      merchSize: selectedSize,
    });
    setIsMpesaModalOpen(true);
  };

  // Payment Success Handlers
  const handlePaymentSuccess = async (receiptNumber: string, phone: string) => {
    setIsMpesaModalOpen(false);

    if (mpesaPaymentMeta?.type === 'ticket' && selectedEventForBooking && bookingTier) {
      const ticketNumber = mpesaPaymentMeta.accountReference;
      const { payload, signature } = await CryptoService.createTicketQrPayload({
        ticketNumber,
        eventId: selectedEventForBooking.id,
        tierId: bookingTier.id,
        attendeePhone: phone,
        purchasedAt: new Date().toISOString(),
      });

      const newTicket: Ticket = {
        id: 'tkt-' + Date.now(),
        ticketNumber,
        eventId: selectedEventForBooking.id,
        eventTitle: selectedEventForBooking.title,
        tierId: bookingTier.id,
        tierName: bookingTier.name,
        venueName: selectedEventForBooking.venueName,
        city: selectedEventForBooking.city,
        date: selectedEventForBooking.date,
        time: selectedEventForBooking.time,
        doorsOpen: selectedEventForBooking.doorsOpen,
        seatInfo: `${bookingTier.name} Section · Pass #0${Math.floor(Math.random() * 90 + 10)}`,
        priceKes: mpesaPaymentMeta.amountKes,
        attendeeName: bookingAttendee.name || 'Attendee',
        attendeePhone: phone,
        attendeeEmail: bookingAttendee.email || 'attendee@gnet.co.ke',
        mpesaReceiptNumber: receiptNumber,
        purchasedAt: new Date().toISOString(),
        isCheckedIn: false,
        qrPayload: payload,
        cryptoSignature: signature,
        isOfflineCached: true,
      };

      storageService.addTicket(newTicket);
      storageService.addTransaction({
        receiptNumber,
        accountNumber: ticketNumber,
        phoneNumber: phone,
        amountKes: mpesaPaymentMeta.amountKes,
        timestamp: new Date().toLocaleString(),
        status: 'COMPLETED',
        description: `${bookingTier.name} - ${selectedEventForBooking.title}`,
      });

      // Send push notification receipt
      handleIncomingPushNotification({
        id: 'notif-' + Date.now(),
        title: `M-Pesa Payment Received (${receiptNumber})`,
        message: `KES ${mpesaPaymentMeta.amountKes.toLocaleString()} confirmed. Digital Pass ${ticketNumber} is active in your wallet.`,
        timestamp: 'Just now',
        type: 'payment',
        eventId: selectedEventForBooking.id,
        read: false,
      });

      reloadData();
      setSelectedEventForBooking(null);
      setSelectedTicketForPass(newTicket);
      setCurrentTab('tickets');
    } else if (mpesaPaymentMeta?.type === 'merch' && mpesaPaymentMeta.merchItem) {
      const newOrder: MerchandiseOrder = {
        id: 'ord-' + Date.now(),
        orderNumber: mpesaPaymentMeta.accountReference,
        itemId: mpesaPaymentMeta.merchItem.id,
        itemName: mpesaPaymentMeta.merchItem.name,
        quantity: 1,
        selectedSize: mpesaPaymentMeta.merchSize,
        totalPriceKes: mpesaPaymentMeta.amountKes,
        mpesaReceiptNumber: receiptNumber,
        orderedAt: new Date().toISOString(),
        pickupCode: `PICKUP-${Math.floor(1000 + Math.random() * 9000)}`,
        isCollected: false,
      };

      storageService.addMerchandiseOrder(newOrder);
      storageService.addTransaction({
        receiptNumber,
        accountNumber: mpesaPaymentMeta.accountReference,
        phoneNumber: phone,
        amountKes: mpesaPaymentMeta.amountKes,
        timestamp: new Date().toLocaleString(),
        status: 'COMPLETED',
        description: `Merch: ${mpesaPaymentMeta.merchItem.name}`,
      });

      handleIncomingPushNotification({
        id: 'notif-' + Date.now(),
        title: `Merch Order Confirmed: ${mpesaPaymentMeta.merchItem.name}`,
        message: `Pickup Code: ${newOrder.pickupCode}. Collect at GNet Merch Stall at venue entrance.`,
        timestamp: 'Just now',
        type: 'payment',
        read: false,
      });

      reloadData();
      setCurrentTab('tickets');
    }
  };

  const unreadNotifCount = notifications.filter((n) => !n.read).length;

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans">
      {/* Offline Status Warning Bar if Offline Simulated */}
      {isOffline && (
        <div className="bg-amber-600 text-neutral-950 text-xs py-1.5 px-4 font-semibold text-center flex items-center justify-center gap-2">
          <WifiOff className="w-4 h-4" />
          <span>
            Offline Simulation Mode: Working from browser cache. Digital passes and gate verification remain 100% active.
          </span>
          <button
            onClick={handleToggleOffline}
            className="underline font-bold hover:text-white ml-2 cursor-pointer"
          >
            Go Online
          </button>
        </div>
      )}

      {/* Main Top Header */}
      <Header
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        userRole={userRole}
        onChangeRole={handleRoleChange}
        deviceMode={deviceMode}
        onChangeDeviceMode={setDeviceMode}
        isOffline={isOffline}
        onToggleOffline={handleToggleOffline}
        unreadCount={unreadNotifCount}
        onOpenNotifications={() => setIsNotificationCenterOpen(true)}
        onOpenSecurity={() => setIsSecurityModalOpen(true)}
      />

      {/* Dynamic Push Toast Notification Banner */}
      {activeToastPush && (
        <div className="fixed top-20 right-4 z-50 max-w-sm w-full bg-neutral-900 border-2 border-emerald-500 rounded-2xl p-4 shadow-2xl animate-in slide-in-from-top-4 duration-300">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping" />
              <div className="flex items-center gap-1.5 text-xs font-bold text-white uppercase tracking-wider">
                <Bell className="w-3.5 h-3.5 text-emerald-400" />
                <span>GNet Push Alert</span>
              </div>
            </div>
            <button
              onClick={() => setActiveToastPush(null)}
              className="text-neutral-400 hover:text-white"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          <p className="text-xs font-bold text-white mt-1.5">{activeToastPush.title}</p>
          <p className="text-xs text-neutral-300 mt-1 leading-relaxed">{activeToastPush.message}</p>
        </div>
      )}

      {/* Main Content Area (Wrapped in MobileFrame if iOS/Android preview enabled) */}
      <main className="flex-1">
        <MobileFrame deviceMode={deviceMode}>
          {currentTab === 'events' && (
            <EventsView
              events={events}
              onSelectEventForBooking={(event) => {
                setSelectedEventForBooking(event);
              }}
            />
          )}

          {currentTab === 'tickets' && (
            <UserDashboard
              tickets={tickets}
              merchandiseOrders={merchandiseOrders}
              onOpenTicketPass={(ticket) => setSelectedTicketForPass(ticket)}
              isOfflineMode={isOffline}
              onToggleOffline={handleToggleOffline}
            />
          )}

          {currentTab === 'merch' && (
            <MerchandiseView
              items={merchandise}
              onSelectMerchToBuy={handleSelectMerchToBuy}
            />
          )}

          {currentTab === 'scanner' && (
            <GateScannerView
              events={events}
              tickets={tickets}
              onCheckInCompleted={reloadData}
              isOfflineMode={isOffline}
            />
          )}

          {currentTab === 'analytics' && (
            <RealTimeAnalyticsView
              events={events}
              tickets={tickets}
              onBroadcastPushNotification={handleIncomingPushNotification}
            />
          )}
        </MobileFrame>
      </main>

      {/* Event Booking Detail Modal */}
      <EventDetailModal
        event={selectedEventForBooking}
        isOpen={!!selectedEventForBooking}
        onClose={() => setSelectedEventForBooking(null)}
        onProceedToMpesa={handleProceedToMpesa}
      />

      {/* M-Pesa STK Push / Paybill Payment Modal */}
      {mpesaPaymentMeta && (
        <MpesaModal
          isOpen={isMpesaModalOpen}
          onClose={() => setIsMpesaModalOpen(false)}
          title={mpesaPaymentMeta.title}
          accountReference={mpesaPaymentMeta.accountReference}
          amountKes={mpesaPaymentMeta.amountKes}
          description={mpesaPaymentMeta.description}
          onPaymentSuccess={handlePaymentSuccess}
        />
      )}

      {/* Digital Ticket Pass Modal */}
      <TicketPassModal
        ticket={selectedTicketForPass}
        isOpen={!!selectedTicketForPass}
        onClose={() => setSelectedTicketForPass(null)}
        isOfflineMode={isOffline}
      />

      {/* Push Notification Drawer */}
      <PushNotificationCenter
        isOpen={isNotificationCenterOpen}
        onClose={() => setIsNotificationCenterOpen(false)}
        notifications={notifications}
        onMarkRead={(id) => {
          storageService.markNotificationRead(id);
          setNotifications(storageService.getNotifications());
        }}
        onMarkAllRead={() => {
          storageService.markAllNotificationsRead();
          setNotifications(storageService.getNotifications());
        }}
      />

      {/* Security & Cryptography Modal */}
      <SecurityModal
        isOpen={isSecurityModalOpen}
        onClose={() => setIsSecurityModalOpen(false)}
      />

      {/* Discreet Footer adhering to guidelines */}
      <footer className="border-t border-neutral-900 bg-neutral-950 py-6 text-xs text-neutral-500">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="font-bold text-neutral-300">GNet East Africa Limited</span>
            <span>·</span>
            <span>Nairobi · Mombasa · Kigali · Kampala</span>
            <span>·</span>
            <span className="font-mono text-emerald-400">Paybill 542800</span>
          </div>
          <div className="flex items-center gap-4 text-neutral-400">
            <button onClick={() => setIsSecurityModalOpen(true)} className="hover:text-white transition-colors">
              Security Architecture
            </button>
            <span>·</span>
            <span>Zero-Knowledge QR Verification</span>
            <span>·</span>
            <span>© 2026 GNet EA</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
