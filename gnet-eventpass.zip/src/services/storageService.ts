import { INITIAL_EVENTS, INITIAL_MERCHANDISE, INITIAL_NOTIFICATIONS, INITIAL_TICKETS } from '../data/mockData';
import { CheckInLogEntry, EventItem, MerchandiseItem, MerchandiseOrder, MpesaTransaction, PushNotification, Ticket } from '../types';

const STORAGE_KEYS = {
  EVENTS: 'gnet_events_v1',
  TICKETS: 'gnet_tickets_v1',
  NOTIFICATIONS: 'gnet_notifications_v1',
  CHECKIN_LOGS: 'gnet_checkin_logs_v1',
  MERCH_ITEMS: 'gnet_merchandise_v1',
  MERCH_ORDERS: 'gnet_merch_orders_v1',
  TRANSACTIONS: 'gnet_mpesa_tx_v1',
  OFFLINE_MODE: 'gnet_offline_sim_active',
};

class StorageService {
  private isBrowser(): boolean {
    return typeof window !== 'undefined';
  }

  // EVENTS
  public getEvents(): EventItem[] {
    if (!this.isBrowser()) return INITIAL_EVENTS;
    const stored = localStorage.getItem(STORAGE_KEYS.EVENTS);
    if (!stored) {
      this.saveEvents(INITIAL_EVENTS);
      return INITIAL_EVENTS;
    }
    try {
      return JSON.parse(stored);
    } catch {
      return INITIAL_EVENTS;
    }
  }

  public saveEvents(events: EventItem[]): void {
    if (this.isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.EVENTS, JSON.stringify(events));
    }
  }

  public updateEventCapacity(eventId: string, newCheckedInCount: number): void {
    const events = this.getEvents();
    const updated = events.map((ev) => (ev.id === eventId ? { ...ev, currentCheckedIn: newCheckedInCount } : ev));
    this.saveEvents(updated);
  }

  // TICKETS
  public getTickets(): Ticket[] {
    if (!this.isBrowser()) return INITIAL_TICKETS;
    const stored = localStorage.getItem(STORAGE_KEYS.TICKETS);
    if (!stored) {
      this.saveTickets(INITIAL_TICKETS);
      return INITIAL_TICKETS;
    }
    try {
      return JSON.parse(stored);
    } catch {
      return INITIAL_TICKETS;
    }
  }

  public saveTickets(tickets: Ticket[]): void {
    if (this.isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.TICKETS, JSON.stringify(tickets));
    }
  }

  public addTicket(ticket: Ticket): void {
    const tickets = this.getTickets();
    const exists = tickets.some((t) => t.ticketNumber === ticket.ticketNumber);
    if (!exists) {
      const updated = [ticket, ...tickets];
      this.saveTickets(updated);
    }
  }

  public markTicketCheckedIn(ticketNumber: string, gate: string, staffName: string): { success: boolean; ticket?: Ticket; reason?: string } {
    const tickets = this.getTickets();
    const ticketIndex = tickets.findIndex((t) => t.ticketNumber.toUpperCase() === ticketNumber.toUpperCase());
    
    if (ticketIndex === -1) {
      return { success: false, reason: 'Ticket number not found in GNet manifest database.' };
    }

    const ticket = tickets[ticketIndex];
    if (ticket.isCheckedIn) {
      return { 
        success: false, 
        ticket, 
        reason: `Pass-back rejected! Already scanned at ${ticket.checkedInAt || 'earlier'} at ${ticket.checkedInGate || 'Gate A'}.` 
      };
    }

    // Mark as checked in
    const updatedTicket: Ticket = {
      ...ticket,
      isCheckedIn: true,
      checkedInAt: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      checkedInGate: gate,
      checkedInByStaffId: staffName,
    };

    tickets[ticketIndex] = updatedTicket;
    this.saveTickets(tickets);

    // Increment event check-in count
    const events = this.getEvents();
    const targetEvent = events.find((e) => e.id === updatedTicket.eventId);
    if (targetEvent) {
      this.updateEventCapacity(targetEvent.id, (targetEvent.currentCheckedIn || 0) + 1);
    }

    // Add to log
    this.addCheckInLog({
      id: 'log-' + Date.now(),
      ticketNumber: updatedTicket.ticketNumber,
      attendeeName: updatedTicket.attendeeName,
      eventTitle: updatedTicket.eventTitle,
      tierName: updatedTicket.tierName,
      gate: gate,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      status: 'valid',
      staffName,
    });

    return { success: true, ticket: updatedTicket };
  }

  // CHECK-IN LOGS
  public getCheckInLogs(): CheckInLogEntry[] {
    if (!this.isBrowser()) return [];
    const stored = localStorage.getItem(STORAGE_KEYS.CHECKIN_LOGS);
    if (!stored) {
      const initialLogs: CheckInLogEntry[] = [
        {
          id: 'log-seed-1',
          ticketNumber: 'GNET-2026-1049',
          attendeeName: 'Amina Wangari',
          eventTitle: 'Nairobi Lights Festival 2026',
          tierName: 'VIP Deck',
          gate: 'Gate A - VIP & Hospitality',
          timestamp: '18:42:15',
          status: 'valid',
          staffName: 'Officer J. Mutua',
        },
        {
          id: 'log-seed-2',
          ticketNumber: 'GNET-2026-7822',
          attendeeName: 'Brian Kiprop',
          eventTitle: 'Nairobi Lights Festival 2026',
          tierName: 'Regular Pass',
          gate: 'Gate B - General East Turnstiles',
          timestamp: '18:41:50',
          status: 'valid',
          staffName: 'Staff #12',
        },
        {
          id: 'log-seed-3',
          ticketNumber: 'GNET-2026-1049',
          attendeeName: 'Amina Wangari',
          eventTitle: 'Nairobi Lights Festival 2026',
          tierName: 'VIP Deck',
          gate: 'Gate C - General West Turnstiles',
          timestamp: '18:43:02',
          status: 'duplicate_rejected',
          staffName: 'Staff #08',
        },
      ];
      this.saveCheckInLogs(initialLogs);
      return initialLogs;
    }
    try {
      return JSON.parse(stored);
    } catch {
      return [];
    }
  }

  public saveCheckInLogs(logs: CheckInLogEntry[]): void {
    if (this.isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.CHECKIN_LOGS, JSON.stringify(logs.slice(0, 100))); // Keep last 100
    }
  }

  public addCheckInLog(entry: CheckInLogEntry): void {
    const logs = this.getCheckInLogs();
    this.saveCheckInLogs([entry, ...logs]);
  }

  // MERCHANDISE
  public getMerchandise(): MerchandiseItem[] {
    if (!this.isBrowser()) return INITIAL_MERCHANDISE;
    const stored = localStorage.getItem(STORAGE_KEYS.MERCH_ITEMS);
    if (!stored) {
      this.saveMerchandise(INITIAL_MERCHANDISE);
      return INITIAL_MERCHANDISE;
    }
    try {
      return JSON.parse(stored);
    } catch {
      return INITIAL_MERCHANDISE;
    }
  }

  public saveMerchandise(items: MerchandiseItem[]): void {
    if (this.isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.MERCH_ITEMS, JSON.stringify(items));
    }
  }

  public getMerchandiseOrders(): MerchandiseOrder[] {
    if (!this.isBrowser()) return [];
    const stored = localStorage.getItem(STORAGE_KEYS.MERCH_ORDERS);
    if (!stored) {
      const seedOrders: MerchandiseOrder[] = [
        {
          id: 'ord-1',
          orderNumber: 'GNET-MRCH-4819',
          itemId: 'merch-hoodie-01',
          itemName: 'GNet Festival Heavyweight Hoodie',
          quantity: 1,
          selectedSize: 'L',
          totalPriceKes: 3800,
          mpesaReceiptNumber: 'QKM71904BV',
          orderedAt: '2026-10-21T11:30:00Z',
          pickupCode: 'PICKUP-4819',
          isCollected: false,
        },
      ];
      this.saveMerchandiseOrders(seedOrders);
      return seedOrders;
    }
    try {
      return JSON.parse(stored);
    } catch {
      return [];
    }
  }

  public saveMerchandiseOrders(orders: MerchandiseOrder[]): void {
    if (this.isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.MERCH_ORDERS, JSON.stringify(orders));
    }
  }

  public addMerchandiseOrder(order: MerchandiseOrder): void {
    const orders = this.getMerchandiseOrders();
    this.saveMerchandiseOrders([order, ...orders]);
  }

  // NOTIFICATIONS
  public getNotifications(): PushNotification[] {
    if (!this.isBrowser()) return INITIAL_NOTIFICATIONS;
    const stored = localStorage.getItem(STORAGE_KEYS.NOTIFICATIONS);
    if (!stored) {
      this.saveNotifications(INITIAL_NOTIFICATIONS);
      return INITIAL_NOTIFICATIONS;
    }
    try {
      return JSON.parse(stored);
    } catch {
      return INITIAL_NOTIFICATIONS;
    }
  }

  public saveNotifications(notifs: PushNotification[]): void {
    if (this.isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.NOTIFICATIONS, JSON.stringify(notifs));
    }
  }

  public addNotification(notification: PushNotification): void {
    const list = this.getNotifications();
    this.saveNotifications([notification, ...list]);
  }

  public markNotificationRead(id: string): void {
    const list = this.getNotifications();
    const updated = list.map((n) => (n.id === id ? { ...n, read: true } : n));
    this.saveNotifications(updated);
  }

  public markAllNotificationsRead(): void {
    const list = this.getNotifications();
    const updated = list.map((n) => ({ ...n, read: true }));
    this.saveNotifications(updated);
  }

  // M-PESA TRANSACTIONS
  public getTransactions(): MpesaTransaction[] {
    if (!this.isBrowser()) return [];
    const stored = localStorage.getItem(STORAGE_KEYS.TRANSACTIONS);
    if (!stored) {
      const seedTx: MpesaTransaction[] = [
        {
          receiptNumber: 'QKL89XA201',
          accountNumber: 'GNET-2026-8941',
          phoneNumber: '254712345678',
          amountKes: 9500,
          timestamp: '2026-10-20 14:22:18',
          status: 'COMPLETED',
          description: 'VIP Deck Pass - Nairobi Lights Festival 2026',
        },
        {
          receiptNumber: 'QKG73PN510',
          accountNumber: 'GNET-2026-3109',
          phoneNumber: '254712345678',
          amountKes: 12500,
          timestamp: '2026-10-18 10:15:44',
          status: 'COMPLETED',
          description: 'Delegate Pass - EA Tech Summit Kigali',
        },
        {
          receiptNumber: 'QKM71904BV',
          accountNumber: 'GNET-MRCH-4819',
          phoneNumber: '254712345678',
          amountKes: 3800,
          timestamp: '2026-10-21 11:30:22',
          status: 'COMPLETED',
          description: 'Merchandise: GNet Heavyweight Hoodie (Size L)',
        },
      ];
      this.saveTransactions(seedTx);
      return seedTx;
    }
    try {
      return JSON.parse(stored);
    } catch {
      return [];
    }
  }

  public saveTransactions(txs: MpesaTransaction[]): void {
    if (this.isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.TRANSACTIONS, JSON.stringify(txs));
    }
  }

  public addTransaction(tx: MpesaTransaction): void {
    const txs = this.getTransactions();
    this.saveTransactions([tx, ...txs]);
  }

  // OFFLINE SIMULATION TOGGLE
  public isOfflineSimulated(): boolean {
    if (!this.isBrowser()) return false;
    return localStorage.getItem(STORAGE_KEYS.OFFLINE_MODE) === 'true';
  }

  public setOfflineSimulated(val: boolean): void {
    if (this.isBrowser()) {
      localStorage.setItem(STORAGE_KEYS.OFFLINE_MODE, val ? 'true' : 'false');
    }
  }
}

export const storageService = new StorageService();
